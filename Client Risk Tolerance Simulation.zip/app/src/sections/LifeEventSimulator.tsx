import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Slider } from '@/components/ui/slider';
import { 
  Heart, 
  Baby, 
  Briefcase, 
  Home, 
  AlertTriangle,
  TrendingDown,
  TrendingUp,
  DollarSign,
  Activity,
  RefreshCw,
  Info
} from 'lucide-react';
import type { RiskProfile, LifeEvent, LifeEventType } from '@/types';
import { lifeEvents } from '@/data/lifeEvents';
import { calculateDynamicRiskScore, getRiskCategory } from '@/data/riskScoring';
import { getClientBehavioralData } from '@/data/sampleClients';
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  Cell
} from 'recharts';

interface LifeEventSimulatorProps {
  client: RiskProfile;
}

const eventIcons: Record<LifeEventType, React.ReactNode> = {
  marriage: <Heart className="h-5 w-5 text-pink-500" />,
  divorce: <Heart className="h-5 w-5 text-red-500" />,
  birth_of_child: <Baby className="h-5 w-5 text-blue-500" />,
  death_of_spouse: <Heart className="h-5 w-5 text-slate-500" />,
  job_change: <Briefcase className="h-5 w-5 text-amber-500" />,
  promotion: <TrendingUp className="h-5 w-5 text-green-500" />,
  job_loss: <TrendingDown className="h-5 w-5 text-red-500" />,
  health_diagnosis: <AlertTriangle className="h-5 w-5 text-orange-500" />,
  inheritance: <DollarSign className="h-5 w-5 text-green-500" />,
  home_purchase: <Home className="h-5 w-5 text-blue-500" />,
  retirement: <Briefcase className="h-5 w-5 text-purple-500" />,
  market_crash: <TrendingDown className="h-5 w-5 text-red-600" />,
  market_boom: <TrendingUp className="h-5 w-5 text-green-600" />
};

export default function LifeEventSimulator({ client }: LifeEventSimulatorProps) {
  const [selectedEvent, setSelectedEvent] = useState<LifeEvent | null>(null);
  const [monthsSinceEvent, setMonthsSinceEvent] = useState(0);
  const [simulatedScore, setSimulatedScore] = useState<number | null>(null);
  const [activeEvents, setActiveEvents] = useState<{ event: LifeEvent; monthsAgo: number }[]>([]);

  const applicableEvents = lifeEvents.filter(event => 
    client.age >= event.ageRange[0] && client.age <= event.ageRange[1]
  );

  const runSimulation = () => {
    const behavioralData = getClientBehavioralData(client.id);
    const events = activeEvents.map(e => e.event);
    const months = activeEvents.map(e => e.monthsAgo);

    const result = calculateDynamicRiskScore(
      client,
      behavioralData,
      events,
      months,
      'stable'
    );

    setSimulatedScore(result.overallScore);
  };

  const addEvent = () => {
    if (selectedEvent) {
      setActiveEvents([...activeEvents, { event: selectedEvent, monthsAgo: monthsSinceEvent }]);
      setSelectedEvent(null);
      setMonthsSinceEvent(0);
    }
  };

  const removeEvent = (index: number) => {
    setActiveEvents(activeEvents.filter((_, i) => i !== index));
  };

  const resetSimulation = () => {
    setActiveEvents([]);
    setSelectedEvent(null);
    setSimulatedScore(null);
    setMonthsSinceEvent(0);
  };

  // Calculate impact visualization data
  const impactData = applicableEvents.map(event => ({
    name: event.name,
    capacityImpact: event.impact.riskCapacity,
    attitudeImpact: event.impact.riskAttitude,
    duration: event.impact.duration
  }));

  const getImpactColor = (impact: number) => {
    if (impact >= 10) return '#10b981';
    if (impact > 0) return '#34d399';
    if (impact === 0) return '#94a3b8';
    if (impact > -10) return '#fbbf24';
    return '#ef4444';
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center">
            <Activity className="h-6 w-6 mr-2 text-blue-500" />
            Life Event Impact Simulator
          </CardTitle>
          <CardDescription>
            Simulate how major life events affect client risk tolerance
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Event Selection */}
            <div className="space-y-4">
              <h3 className="font-semibold text-slate-900">Select Life Event</h3>
              <div className="grid grid-cols-2 gap-2 max-h-64 overflow-y-auto">
                {applicableEvents.map(event => (
                  <button
                    key={event.id}
                    onClick={() => setSelectedEvent(event)}
                    className={`p-3 rounded-lg border text-left transition-all ${
                      selectedEvent?.id === event.id
                        ? 'border-blue-500 bg-blue-50'
                        : 'border-slate-200 hover:border-blue-300 hover:bg-slate-50'
                    }`}
                  >
                    <div className="flex items-center space-x-2">
                      {eventIcons[event.type]}
                      <span className="font-medium text-sm">{event.name}</span>
                    </div>
                  </button>
                ))}
              </div>

              {selectedEvent && (
                <div className="bg-slate-50 p-4 rounded-lg space-y-4">
                  <div>
                    <h4 className="font-semibold text-slate-900 flex items-center">
                      {eventIcons[selectedEvent.type]}
                      <span className="ml-2">{selectedEvent.name}</span>
                    </h4>
                    <p className="text-sm text-slate-600 mt-1">{selectedEvent.description}</p>
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <p className="text-xs text-slate-500">Risk Capacity Impact</p>
                      <p className={`text-lg font-semibold ${
                        selectedEvent.impact.riskCapacity >= 0 ? 'text-green-600' : 'text-red-600'
                      }`}>
                        {selectedEvent.impact.riskCapacity > 0 ? '+' : ''}
                        {selectedEvent.impact.riskCapacity}
                      </p>
                    </div>
                    <div>
                      <p className="text-xs text-slate-500">Risk Attitude Impact</p>
                      <p className={`text-lg font-semibold ${
                        selectedEvent.impact.riskAttitude >= 0 ? 'text-green-600' : 'text-red-600'
                      }`}>
                        {selectedEvent.impact.riskAttitude > 0 ? '+' : ''}
                        {selectedEvent.impact.riskAttitude}
                      </p>
                    </div>
                  </div>

                  <div>
                    <p className="text-xs text-slate-500 mb-2">Months Since Event</p>
                    <Slider
                      value={[monthsSinceEvent]}
                      onValueChange={(value) => setMonthsSinceEvent(value[0])}
                      max={selectedEvent.impact.duration}
                      step={1}
                    />
                    <p className="text-sm text-slate-600 mt-1">{monthsSinceEvent} months ago</p>
                  </div>

                  <Button onClick={addEvent} className="w-full">
                    Add to Simulation
                  </Button>
                </div>
              )}
            </div>

            {/* Simulation Results */}
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="font-semibold text-slate-900">Active Events</h3>
                <Button variant="outline" size="sm" onClick={resetSimulation}>
                  <RefreshCw className="h-4 w-4 mr-2" />
                  Reset
                </Button>
              </div>

              {activeEvents.length === 0 ? (
                <div className="bg-slate-50 p-8 rounded-lg text-center">
                  <Info className="h-12 w-12 text-slate-400 mx-auto mb-4" />
                  <p className="text-slate-600">No events added yet. Select a life event to begin simulation.</p>
                </div>
              ) : (
                <div className="space-y-2">
                  {activeEvents.map((item, index) => (
                    <div key={index} className="flex items-center justify-between p-3 bg-slate-50 rounded-lg">
                      <div className="flex items-center space-x-3">
                        {eventIcons[item.event.type]}
                        <div>
                          <p className="font-medium text-sm">{item.event.name}</p>
                          <p className="text-xs text-slate-500">{item.monthsAgo} months ago</p>
                        </div>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Badge variant="outline" className={
                          item.event.impact.riskCapacity + item.event.impact.riskAttitude >= 0
                            ? 'text-green-600 border-green-300'
                            : 'text-red-600 border-red-300'
                        }>
                          {item.event.impact.riskCapacity + item.event.impact.riskAttitude > 0 ? '+' : ''}
                          {item.event.impact.riskCapacity + item.event.impact.riskAttitude}
                        </Badge>
                        <Button 
                          variant="ghost" 
                          size="sm"
                          onClick={() => removeEvent(index)}
                        >
                          ×
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              )}

              <Button 
                onClick={runSimulation} 
                className="w-full"
                disabled={activeEvents.length === 0}
              >
                Run Simulation
              </Button>

              {/* Score Comparison */}
              <Card className="mt-4">
                <CardContent className="p-4">
                  <h4 className="font-semibold text-slate-900 mb-4">Risk Score Impact</h4>
                  <div className="flex items-center justify-around">
                    <div className="text-center">
                      <p className="text-sm text-slate-500">Current Score</p>
                      <p className="text-3xl font-bold text-blue-600">{client.compositeScore}</p>
                      <p className="text-xs text-slate-500">{getRiskCategory(client.compositeScore)}</p>
                    </div>
                    <div className="text-2xl text-slate-400">→</div>
                    <div className="text-center">
                      <p className="text-sm text-slate-500">Projected Score</p>
                      <p className={`text-3xl font-bold ${
                        simulatedScore !== null
                          ? simulatedScore > client.compositeScore ? 'text-green-600' : 'text-red-600'
                          : 'text-slate-400'
                      }`}>
                        {simulatedScore !== null ? Math.round(simulatedScore) : '--'}
                      </p>
                      <p className="text-xs text-slate-500">
                        {simulatedScore !== null ? getRiskCategory(simulatedScore) : 'Simulate to see'}
                      </p>
                    </div>
                  </div>

                  {simulatedScore !== null && (
                    <div className="mt-4 p-3 bg-slate-50 rounded-lg">
                      <p className="text-sm text-slate-700">
                        <strong>Impact:</strong>{' '}
                        {simulatedScore > client.compositeScore ? (
                          <span className="text-green-600">
                            Risk tolerance increases by {Math.round(simulatedScore - client.compositeScore)} points
                          </span>
                        ) : simulatedScore < client.compositeScore ? (
                          <span className="text-red-600">
                            Risk tolerance decreases by {Math.round(client.compositeScore - simulatedScore)} points
                          </span>
                        ) : (
                          <span className="text-slate-600">No change in risk tolerance</span>
                        )}
                      </p>
                    </div>
                  )}
                </CardContent>
              </Card>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Event Impact Visualization */}
      <Card>
        <CardHeader>
          <CardTitle>Life Event Impact Analysis</CardTitle>
          <CardDescription>
            Visual comparison of risk impact across different life events
          </CardDescription>
        </CardHeader>
        <CardContent>
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={impactData} layout="vertical" margin={{ left: 100 }}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis type="number" domain={[-25, 25]} />
              <YAxis dataKey="name" type="category" width={100} tick={{ fontSize: 11 }} />
              <Tooltip />
              <Bar dataKey="capacityImpact" name="Risk Capacity Impact" fill="#3b82f6">
                {impactData.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={getImpactColor(entry.capacityImpact)} />
                ))}
              </Bar>
              <Bar dataKey="attitudeImpact" name="Risk Attitude Impact" fill="#8b5cf6">
                {impactData.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={getImpactColor(entry.attitudeImpact)} />
                ))}
              </Bar>
            </BarChart>
          </ResponsiveContainer>

          <div className="mt-6 grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="bg-green-50 p-4 rounded-lg">
              <h4 className="font-semibold text-green-900 mb-2">Positive Impact Events</h4>
              <ul className="space-y-1 text-sm text-green-800">
                {lifeEvents
                  .filter(e => e.impact.riskCapacity > 5 || e.impact.riskAttitude > 5)
                  .map(e => (
                    <li key={e.id}>• {e.name}</li>
                  ))}
              </ul>
            </div>
            <div className="bg-red-50 p-4 rounded-lg">
              <h4 className="font-semibold text-red-900 mb-2">Negative Impact Events</h4>
              <ul className="space-y-1 text-sm text-red-800">
                {lifeEvents
                  .filter(e => e.impact.riskCapacity < -5 || e.impact.riskAttitude < -5)
                  .map(e => (
                    <li key={e.id}>• {e.name}</li>
                  ))}
              </ul>
            </div>
            <div className="bg-blue-50 p-4 rounded-lg">
              <h4 className="font-semibold text-blue-900 mb-2">Key Insights</h4>
              <ul className="space-y-1 text-sm text-blue-800">
                <li>• Job loss has the strongest negative impact (-35 points)</li>
                <li>• Market crashes affect attitude more than capacity</li>
                <li>• Marriage effects typically last 12 months</li>
                <li>• Health diagnoses have lasting multi-year impact</li>
              </ul>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
