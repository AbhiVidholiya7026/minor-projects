import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { 
  User, 
  Briefcase, 
  Users, 
  Target, 
  Calendar, 
  IndianRupee,
  PieChart,
  Shield,
  BookOpen,
  Activity
} from 'lucide-react';
import type { RiskProfile } from '@/types';
import { getRiskCategory, getRecommendedAllocation } from '@/data/riskScoring';
import { 
  LineChart, 
  Line, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  RadarChart,
  PolarGrid,
  PolarAngleAxis,
  PolarRadiusAxis,
  Radar
} from 'recharts';

interface ClientProfileProps {
  client: RiskProfile;
  onClientChange: (client: RiskProfile) => void;
  allClients: RiskProfile[];
}

const familyStatusLabels: Record<string, string> = {
  single: 'Single',
  married_no_children: 'Married, No Children',
  married_with_children: 'Married with Children',
  divorced: 'Divorced',
  widowed: 'Widowed',
  retired: 'Retired'
};

export default function ClientProfile({ client, onClientChange, allClients }: ClientProfileProps) {
  const [activeTab, setActiveTab] = useState('overview');

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-IN', {
      style: 'currency',
      currency: 'INR',
      maximumFractionDigits: 0
    }).format(amount);
  };

  const riskCategory = getRiskCategory(client.compositeScore);
  const recommendedAllocation = getRecommendedAllocation(client.compositeScore);

  // Prepare chart data
  const historyData = client.assessmentHistory.map(h => ({
    date: new Date(h.date).toLocaleDateString('en-US', { month: 'short', year: '2-digit' }),
    score: h.compositeScore,
    capacity: h.riskCapacity,
    attitude: h.riskAttitude
  }));

  const radarData = [
    { subject: 'Risk Capacity', A: client.riskCapacity, fullMark: 100 },
    { subject: 'Risk Attitude', A: client.riskAttitude, fullMark: 100 },
    { subject: 'Risk Knowledge', A: client.riskKnowledge, fullMark: 100 },
    { subject: 'Composite Score', A: client.compositeScore, fullMark: 100 },
  ];

  const allocationData = Object.entries(recommendedAllocation).map(([key, value]) => ({
    name: key.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase()),
    value
  }));

  const getScoreColor = (score: number) => {
    if (score >= 70) return 'text-green-600';
    if (score >= 50) return 'text-blue-600';
    if (score >= 35) return 'text-amber-600';
    return 'text-red-600';
  };

  const getScoreBgColor = (score: number) => {
    if (score >= 70) return 'bg-green-500';
    if (score >= 50) return 'bg-blue-500';
    if (score >= 35) return 'bg-amber-500';
    return 'bg-red-500';
  };

  return (
    <div className="space-y-6">
      {/* Client Selector */}
      <Card>
        <CardContent className="p-4">
          <div className="flex items-center space-x-4">
            <span className="text-sm font-medium text-slate-700">Select Client:</span>
            <Select 
              value={client.id} 
              onValueChange={(value) => {
                const selected = allClients.find(c => c.id === value);
                if (selected) onClientChange(selected);
              }}
            >
              <SelectTrigger className="w-80">
                <SelectValue placeholder="Select a client" />
              </SelectTrigger>
              <SelectContent>
                {allClients.map(c => (
                  <SelectItem key={c.id} value={c.id}>
                    {c.clientName} - {c.occupation}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      {/* Client Header */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card className="md:col-span-3">
          <CardContent className="p-6">
            <div className="flex items-start justify-between">
              <div className="flex items-center space-x-4">
                <div className="w-16 h-16 rounded-full bg-gradient-to-br from-blue-500 to-indigo-600 flex items-center justify-center">
                  <User className="h-8 w-8 text-white" />
                </div>
                <div>
                  <h2 className="text-2xl font-bold text-slate-900">{client.clientName}</h2>
                  <p className="text-slate-600">{client.occupation}</p>
                  <div className="flex items-center space-x-2 mt-2">
                    <Badge variant="outline" className="flex items-center space-x-1">
                      <Calendar className="h-3 w-3" />
                      <span>Age {client.age}</span>
                    </Badge>
                    <Badge variant="outline" className="flex items-center space-x-1">
                      <IndianRupee className="h-3 w-3" />
                      <span>{formatCurrency(client.income)}/year</span>
                    </Badge>
                    <Badge variant="outline" className="flex items-center space-x-1">
                      <Users className="h-3 w-3" />
                      <span>{familyStatusLabels[client.familyStatus]}</span>
                    </Badge>
                  </div>
                </div>
              </div>
              <div className="text-right">
                <div className={`text-4xl font-bold ${getScoreColor(client.compositeScore)}`}>
                  {client.compositeScore}
                </div>
                <p className="text-sm text-slate-500">Risk Score</p>
                <Badge className={`mt-2 ${getScoreBgColor(client.compositeScore)} text-white`}>
                  {riskCategory}
                </Badge>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="text-center">
              <p className="text-sm text-slate-500 mb-2">Last Assessment</p>
              <p className="text-lg font-semibold text-slate-900">
                {new Date(client.lastAssessment).toLocaleDateString('en-US', {
                  month: 'short',
                  day: 'numeric',
                  year: 'numeric'
                })}
              </p>
              <Button variant="outline" size="sm" className="mt-4 w-full">
                <Activity className="h-4 w-4 mr-2" />
                Reassess Now
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Detailed Tabs */}
      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid grid-cols-4 gap-4">
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="components">Risk Components</TabsTrigger>
          <TabsTrigger value="history">Score History</TabsTrigger>
          <TabsTrigger value="goals">Financial Goals</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {/* Risk Scores */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg flex items-center">
                  <Shield className="h-5 w-5 mr-2 text-blue-500" />
                  Risk Components
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <div className="flex justify-between mb-1">
                    <span className="text-sm text-slate-600">Risk Capacity</span>
                    <span className={`text-sm font-semibold ${getScoreColor(client.riskCapacity)}`}>
                      {client.riskCapacity}
                    </span>
                  </div>
                  <Progress value={client.riskCapacity} className="h-2" />
                  <p className="text-xs text-slate-500 mt-1">
                    Financial ability to absorb losses
                  </p>
                </div>
                <div>
                  <div className="flex justify-between mb-1">
                    <span className="text-sm text-slate-600">Risk Attitude</span>
                    <span className={`text-sm font-semibold ${getScoreColor(client.riskAttitude)}`}>
                      {client.riskAttitude}
                    </span>
                  </div>
                  <Progress value={client.riskAttitude} className="h-2" />
                  <p className="text-xs text-slate-500 mt-1">
                    Emotional comfort with uncertainty
                  </p>
                </div>
                <div>
                  <div className="flex justify-between mb-1">
                    <span className="text-sm text-slate-600">Risk Knowledge</span>
                    <span className={`text-sm font-semibold ${getScoreColor(client.riskKnowledge)}`}>
                      {client.riskKnowledge}
                    </span>
                  </div>
                  <Progress value={client.riskKnowledge} className="h-2" />
                  <p className="text-xs text-slate-500 mt-1">
                    Understanding of investment risks
                  </p>
                </div>
              </CardContent>
            </Card>

            {/* Radar Chart */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg flex items-center">
                  <PieChart className="h-5 w-5 mr-2 text-purple-500" />
                  Risk Profile
                </CardTitle>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={200}>
                  <RadarChart data={radarData}>
                    <PolarGrid />
                    <PolarAngleAxis dataKey="subject" tick={{ fontSize: 10 }} />
                    <PolarRadiusAxis angle={30} domain={[0, 100]} tick={false} />
                    <Radar
                      name={client.clientName}
                      dataKey="A"
                      stroke="#3b82f6"
                      fill="#3b82f6"
                      fillOpacity={0.3}
                    />
                  </RadarChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            {/* Recommended Allocation */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg flex items-center">
                  <Target className="h-5 w-5 mr-2 text-green-500" />
                  Recommended Allocation
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  {allocationData.slice(0, 5).map((item, index) => (
                    <div key={index} className="flex items-center justify-between">
                      <span className="text-sm text-slate-600">{item.name}</span>
                      <div className="flex items-center space-x-2">
                        <div className="w-20 bg-slate-200 rounded-full h-2">
                          <div 
                            className="h-2 rounded-full bg-blue-500"
                            style={{ width: `${item.value * 2}%` }}
                          />
                        </div>
                        <span className="text-sm font-medium w-10 text-right">{item.value}%</span>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="components">
          <Card>
            <CardHeader>
              <CardTitle>Detailed Risk Component Analysis</CardTitle>
              <CardDescription>
                Understanding the factors that contribute to the overall risk score
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div className="bg-blue-50 p-6 rounded-lg">
                  <div className="flex items-center space-x-2 mb-4">
                    <Briefcase className="h-6 w-6 text-blue-600" />
                    <h3 className="text-lg font-semibold text-blue-900">Risk Capacity</h3>
                  </div>
                  <div className="text-3xl font-bold text-blue-700 mb-2">{client.riskCapacity}</div>
                  <p className="text-sm text-blue-600 mb-4">
                    Based on income, emergency reserves, debt levels, and time horizon
                  </p>
                  <ul className="space-y-2 text-sm text-blue-800">
                    <li className="flex items-center space-x-2">
                      <div className="w-1.5 h-1.5 rounded-full bg-blue-500" />
                      <span>Annual Income: {formatCurrency(client.income)}</span>
                    </li>
                    <li className="flex items-center space-x-2">
                      <div className="w-1.5 h-1.5 rounded-full bg-blue-500" />
                      <span>Years to Retirement: {60 - client.age}</span>
                    </li>
                    <li className="flex items-center space-x-2">
                      <div className="w-1.5 h-1.5 rounded-full bg-blue-500" />
                      <span>Family Status: {familyStatusLabels[client.familyStatus]}</span>
                    </li>
                  </ul>
                </div>

                <div className="bg-purple-50 p-6 rounded-lg">
                  <div className="flex items-center space-x-2 mb-4">
                    <Activity className="h-6 w-6 text-purple-600" />
                    <h3 className="text-lg font-semibold text-purple-900">Risk Attitude</h3>
                  </div>
                  <div className="text-3xl font-bold text-purple-700 mb-2">{client.riskAttitude}</div>
                  <p className="text-sm text-purple-600 mb-4">
                    Emotional and psychological comfort with investment uncertainty
                  </p>
                  <ul className="space-y-2 text-sm text-purple-800">
                    <li className="flex items-center space-x-2">
                      <div className="w-1.5 h-1.5 rounded-full bg-purple-500" />
                      <span>Loss Tolerance: {client.riskAttitude > 60 ? 'High' : client.riskAttitude > 40 ? 'Moderate' : 'Low'}</span>
                    </li>
                    <li className="flex items-center space-x-2">
                      <div className="w-1.5 h-1.5 rounded-full bg-purple-500" />
                      <span>Volatility Comfort: {client.riskAttitude > 60 ? 'Comfortable' : 'Cautious'}</span>
                    </li>
                    <li className="flex items-center space-x-2">
                      <div className="w-1.5 h-1.5 rounded-full bg-purple-500" />
                      <span>Decision Style: Analytical</span>
                    </li>
                  </ul>
                </div>

                <div className="bg-green-50 p-6 rounded-lg">
                  <div className="flex items-center space-x-2 mb-4">
                    <BookOpen className="h-6 w-6 text-green-600" />
                    <h3 className="text-lg font-semibold text-green-900">Risk Knowledge</h3>
                  </div>
                  <div className="text-3xl font-bold text-green-700 mb-2">{client.riskKnowledge}</div>
                  <p className="text-sm text-green-600 mb-4">
                    Understanding of investment concepts, markets, and risk management
                  </p>
                  <ul className="space-y-2 text-sm text-green-800">
                    <li className="flex items-center space-x-2">
                      <div className="w-1.5 h-1.5 rounded-full bg-green-500" />
                      <span>Investment Experience: {client.age > 40 ? '10+ years' : '5+ years'}</span>
                    </li>
                    <li className="flex items-center space-x-2">
                      <div className="w-1.5 h-1.5 rounded-full bg-green-500" />
                      <span>Financial Literacy: {client.riskKnowledge > 70 ? 'Advanced' : 'Intermediate'}</span>
                    </li>
                    <li className="flex items-center space-x-2">
                      <div className="w-1.5 h-1.5 rounded-full bg-green-500" />
                      <span>Diversification Understanding: Yes</span>
                    </li>
                  </ul>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="history">
          <Card>
            <CardHeader>
              <CardTitle>Risk Score History</CardTitle>
              <CardDescription>
                Track how risk tolerance has evolved over time
              </CardDescription>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <LineChart data={historyData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="date" />
                  <YAxis domain={[0, 100]} />
                  <Tooltip />
                  <Line 
                    type="monotone" 
                    dataKey="score" 
                    name="Composite Score" 
                    stroke="#3b82f6" 
                    strokeWidth={2}
                    dot={{ fill: '#3b82f6' }}
                  />
                  <Line 
                    type="monotone" 
                    dataKey="capacity" 
                    name="Risk Capacity" 
                    stroke="#10b981" 
                    strokeWidth={2}
                    dot={{ fill: '#10b981' }}
                  />
                  <Line 
                    type="monotone" 
                    dataKey="attitude" 
                    name="Risk Attitude" 
                    stroke="#8b5cf6" 
                    strokeWidth={2}
                    dot={{ fill: '#8b5cf6' }}
                  />
                </LineChart>
              </ResponsiveContainer>

              <div className="mt-6">
                <h4 className="font-semibold text-slate-900 mb-4">Assessment History</h4>
                <div className="space-y-3">
                  {client.assessmentHistory.map((record, index) => (
                    <div key={index} className="flex items-center justify-between p-3 bg-slate-50 rounded-lg">
                      <div className="flex items-center space-x-4">
                        <Calendar className="h-4 w-4 text-slate-400" />
                        <span className="text-sm text-slate-700">
                          {new Date(record.date).toLocaleDateString('en-US', {
                            month: 'long',
                            year: 'numeric'
                          })}
                        </span>
                      </div>
                      <div className="flex items-center space-x-6">
                        <div className="text-center">
                          <p className="text-xs text-slate-500">Capacity</p>
                          <p className={`font-semibold ${getScoreColor(record.riskCapacity)}`}>
                            {record.riskCapacity}
                          </p>
                        </div>
                        <div className="text-center">
                          <p className="text-xs text-slate-500">Attitude</p>
                          <p className={`font-semibold ${getScoreColor(record.riskAttitude)}`}>
                            {record.riskAttitude}
                          </p>
                        </div>
                        <div className="text-center">
                          <p className="text-xs text-slate-500">Knowledge</p>
                          <p className={`font-semibold ${getScoreColor(record.riskKnowledge)}`}>
                            {record.riskKnowledge}
                          </p>
                        </div>
                        <div className="text-center">
                          <p className="text-xs text-slate-500">Overall</p>
                          <p className={`font-semibold ${getScoreColor(record.compositeScore)}`}>
                            {record.compositeScore}
                          </p>
                        </div>
                        {record.trigger && (
                          <Badge variant="outline" className="text-amber-600 border-amber-300">
                            {record.trigger}
                          </Badge>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="goals">
          <Card>
            <CardHeader>
              <CardTitle>Financial Goals</CardTitle>
              <CardDescription>
                Client's financial objectives and target timelines
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {client.financialGoals.map(goal => (
                  <Card key={goal.id} className="border-l-4 border-l-blue-500">
                    <CardContent className="p-4">
                      <div className="flex items-start justify-between">
                        <div>
                          <h4 className="font-semibold text-slate-900">{goal.name}</h4>
                          <p className="text-sm text-slate-500 capitalize">{goal.goalType.replace(/_/g, ' ')}</p>
                        </div>
                        <Badge className={
                          goal.priority === 'high' ? 'bg-red-100 text-red-800' :
                          goal.priority === 'medium' ? 'bg-amber-100 text-amber-800' :
                          'bg-green-100 text-green-800'
                        }>
                          {goal.priority} priority
                        </Badge>
                      </div>
                      <div className="mt-4 space-y-2">
                        <div className="flex justify-between text-sm">
                          <span className="text-slate-600">Target Amount</span>
                          <span className="font-semibold">{formatCurrency(goal.targetAmount)}</span>
                        </div>
                        <div className="flex justify-between text-sm">
                          <span className="text-slate-600">Target Date</span>
                          <span className="font-semibold">
                            {new Date(goal.targetDate).toLocaleDateString('en-US', {
                              month: 'short',
                              year: 'numeric'
                            })}
                          </span>
                        </div>
                        <div className="flex justify-between text-sm">
                          <span className="text-slate-600">Time Remaining</span>
                          <span className="font-semibold">
                            {Math.ceil((new Date(goal.targetDate).getTime() - new Date().getTime()) / (1000 * 60 * 60 * 24 * 30))} months
                          </span>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
