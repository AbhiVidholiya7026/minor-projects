import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { 
  Target, 
  AlertTriangle, 
  CheckCircle, 
  TrendingUp,
  TrendingDown,
  ArrowRight,
  RefreshCw,
  Shield
} from 'lucide-react';
import type { RiskProfile } from '@/types';
import { getRiskCategory, getRecommendedAllocation } from '@/data/riskScoring';
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  Cell
} from 'recharts';

interface PortfolioAlignmentProps {
  client: RiskProfile;
}

// Sample current allocation (would come from actual portfolio data)
const sampleCurrentAllocation: Record<string, number> = {
  large_cap_equity: 30,
  mid_cap_equity: 15,
  small_cap_equity: 10,
  international_equity: 10,
  government_bonds: 15,
  corporate_bonds: 10,
  gold: 5,
  cash: 5
};

export default function PortfolioAlignment({ client }: PortfolioAlignmentProps) {
  const [showRebalance, setShowRebalance] = useState(false);
  
  const recommendedAllocation = getRecommendedAllocation(client.compositeScore);
  const riskCategory = getRiskCategory(client.compositeScore);

  // Calculate alignment
  const allocationComparison = Object.keys(recommendedAllocation).map(key => {
    const recommended = recommendedAllocation[key] || 0;
    const current = sampleCurrentAllocation[key] || 0;
    const difference = current - recommended;
    
    return {
      assetClass: key.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase()),
      recommended,
      current,
      difference,
      aligned: Math.abs(difference) <= 3
    };
  });

  const alignedAssets = allocationComparison.filter(a => a.aligned).length;
  const totalAssets = allocationComparison.length;
  const alignmentScore = Math.round((alignedAssets / totalAssets) * 100);

  const getAlignmentStatus = (score: number) => {
    if (score >= 90) return { label: 'Excellent', color: 'text-green-600', bg: 'bg-green-100' };
    if (score >= 70) return { label: 'Good', color: 'text-blue-600', bg: 'bg-blue-100' };
    if (score >= 50) return { label: 'Moderate', color: 'text-amber-600', bg: 'bg-amber-100' };
    return { label: 'Poor', color: 'text-red-600', bg: 'bg-red-100' };
  };

  const status = getAlignmentStatus(alignmentScore);

  const driftAnalysis = allocationComparison
    .filter(a => !a.aligned)
    .sort((a, b) => Math.abs(b.difference) - Math.abs(a.difference));

  return (
    <div className="space-y-6">
      {/* Alignment Score */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card className="md:col-span-2">
          <CardHeader>
            <CardTitle className="flex items-center">
              <Target className="h-6 w-6 mr-2 text-blue-500" />
              Portfolio-Profile Alignment
            </CardTitle>
            <CardDescription>
              Compare current portfolio allocation with risk-profile recommendations
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex items-center justify-between">
              <div className="text-center flex-1">
                <p className="text-sm text-slate-500 mb-2">Alignment Score</p>
                <p className={`text-5xl font-bold ${status.color}`}>
                  {alignmentScore}%
                </p>
                <Badge className={`mt-2 ${status.bg} ${status.color}`}>
                  {status.label}
                </Badge>
              </div>
              <div className="h-20 w-px bg-slate-200" />
              <div className="text-center flex-1">
                <p className="text-sm text-slate-500 mb-2">Risk Profile</p>
                <p className="text-3xl font-bold text-slate-700">
                  {client.compositeScore}
                </p>
                <p className="text-xs text-slate-500 mt-1">{riskCategory}</p>
              </div>
              <div className="h-20 w-px bg-slate-200" />
              <div className="text-center flex-1">
                <p className="text-sm text-slate-500 mb-2">Assets Aligned</p>
                <p className="text-3xl font-bold text-slate-700">
                  {alignedAssets}/{totalAssets}
                </p>
                <p className="text-xs text-slate-500 mt-1">
                  {driftAnalysis.length} need attention
                </p>
              </div>
            </div>

            {alignmentScore < 70 && (
              <div className="mt-6 p-4 bg-amber-50 rounded-lg border-l-4 border-amber-500">
                <div className="flex items-start space-x-3">
                  <AlertTriangle className="h-5 w-5 text-amber-600 mt-0.5" />
                  <div>
                    <h4 className="font-semibold text-amber-900">Rebalancing Recommended</h4>
                    <p className="text-sm text-amber-700 mt-1">
                      Portfolio allocation deviates from risk profile recommendations. 
                      Consider rebalancing to maintain alignment with client risk tolerance.
                    </p>
                    <Button 
                      variant="outline" 
                      size="sm" 
                      className="mt-3"
                      onClick={() => setShowRebalance(!showRebalance)}
                    >
                      {showRebalance ? 'Hide Details' : 'View Rebalancing Plan'}
                    </Button>
                  </div>
                </div>
              </div>
            )}

            {alignmentScore >= 90 && (
              <div className="mt-6 p-4 bg-green-50 rounded-lg border-l-4 border-green-500">
                <div className="flex items-start space-x-3">
                  <CheckCircle className="h-5 w-5 text-green-600 mt-0.5" />
                  <div>
                    <h4 className="font-semibold text-green-900">Excellent Alignment</h4>
                    <p className="text-sm text-green-700 mt-1">
                      Portfolio is well-aligned with client risk profile. Continue monitoring 
                      for any changes.
                    </p>
                  </div>
                </div>
              </div>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-lg">Quick Actions</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <Button className="w-full" variant="outline">
              <RefreshCw className="h-4 w-4 mr-2" />
              Run Rebalancing Analysis
            </Button>
            <Button className="w-full" variant="outline">
              <Shield className="h-4 w-4 mr-2" />
              Check Tax Implications
            </Button>
            <Button className="w-full" variant="outline">
              <Target className="h-4 w-4 mr-2" />
              Goal-Based Review
            </Button>
          </CardContent>
        </Card>
      </div>

      {/* Allocation Comparison Chart */}
      <Card>
        <CardHeader>
          <CardTitle>Allocation Comparison</CardTitle>
          <CardDescription>
            Current allocation vs. recommended based on risk profile
          </CardDescription>
        </CardHeader>
        <CardContent>
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={allocationComparison} layout="vertical" margin={{ left: 100 }}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis type="number" domain={[0, 50]} />
              <YAxis dataKey="assetClass" type="category" width={100} tick={{ fontSize: 11 }} />
              <Tooltip />
              <Bar dataKey="recommended" name="Recommended %" fill="#3b82f6" />
              <Bar dataKey="current" name="Current %" fill="#10b981">
                {allocationComparison.map((entry, index) => (
                  <Cell 
                    key={`cell-${index}`} 
                    fill={entry.aligned ? '#10b981' : '#ef4444'} 
                  />
                ))}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>

      {/* Drift Analysis */}
      {driftAnalysis.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <AlertTriangle className="h-5 w-5 mr-2 text-amber-500" />
              Allocation Drift Analysis
            </CardTitle>
            <CardDescription>
              Assets that have drifted beyond acceptable tolerance from target allocation
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {driftAnalysis.map((asset, index) => (
                <div key={index} className="p-4 bg-slate-50 rounded-lg">
                  <div className="flex items-center justify-between mb-2">
                    <h4 className="font-semibold text-slate-900">{asset.assetClass}</h4>
                    <Badge className={
                      asset.difference > 0 
                        ? 'bg-red-100 text-red-800' 
                        : 'bg-amber-100 text-amber-800'
                    }>
                      {asset.difference > 0 ? '+' : ''}{asset.difference}% drift
                    </Badge>
                  </div>
                  <div className="flex items-center space-x-4">
                    <div className="flex-1">
                      <div className="flex justify-between text-sm mb-1">
                        <span className="text-slate-600">Current: {asset.current}%</span>
                        <span className="text-slate-600">Target: {asset.recommended}%</span>
                      </div>
                      <div className="relative h-4 bg-slate-200 rounded-full overflow-hidden">
                        <div 
                          className={`absolute h-full rounded-full ${
                            asset.difference > 0 ? 'bg-red-500' : 'bg-amber-500'
                          }`}
                          style={{ 
                            left: `${Math.min(asset.current, asset.recommended)}%`,
                            width: `${Math.abs(asset.difference)}%`
                          }}
                        />
                        <div 
                          className="absolute h-full w-1 bg-slate-800"
                          style={{ left: `${asset.recommended}%` }}
                        />
                      </div>
                    </div>
                    <div className="text-right">
                      <p className="text-sm font-medium text-slate-700">
                        {asset.difference > 0 ? (
                          <span className="flex items-center text-red-600">
                            <TrendingUp className="h-4 w-4 mr-1" />
                            Overweight
                          </span>
                        ) : (
                          <span className="flex items-center text-amber-600">
                            <TrendingDown className="h-4 w-4 mr-1" />
                            Underweight
                          </span>
                        )}
                      </p>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Rebalancing Plan */}
      {showRebalance && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <RefreshCw className="h-5 w-5 mr-2 text-blue-500" />
              Recommended Rebalancing Plan
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b border-slate-200">
                    <th className="text-left py-3 px-4">Asset Class</th>
                    <th className="text-center py-3 px-4">Current %</th>
                    <th className="text-center py-3 px-4">Target %</th>
                    <th className="text-center py-3 px-4">Action</th>
                    <th className="text-center py-3 px-4">Amount</th>
                  </tr>
                </thead>
                <tbody>
                  {allocationComparison
                    .filter(a => !a.aligned)
                    .map((asset, index) => (
                      <tr key={index} className="border-b border-slate-100">
                        <td className="py-3 px-4 font-medium">{asset.assetClass}</td>
                        <td className="text-center py-3 px-4">{asset.current}%</td>
                        <td className="text-center py-3 px-4">{asset.recommended}%</td>
                        <td className="text-center py-3 px-4">
                          <Badge className={
                            asset.difference > 0 
                              ? 'bg-red-100 text-red-800' 
                              : 'bg-green-100 text-green-800'
                          }>
                            {asset.difference > 0 ? 'Reduce' : 'Increase'}
                          </Badge>
                        </td>
                        <td className="text-center py-3 px-4">
                          <span className={asset.difference > 0 ? 'text-red-600' : 'text-green-600'}>
                            {Math.abs(asset.difference)}%
                          </span>
                        </td>
                      </tr>
                    ))}
                </tbody>
              </table>
            </div>

            <div className="mt-6 p-4 bg-blue-50 rounded-lg">
              <h4 className="font-semibold text-blue-900 mb-2">Rebalancing Considerations</h4>
              <ul className="space-y-2 text-sm text-blue-800">
                <li className="flex items-start space-x-2">
                  <ArrowRight className="h-4 w-4 mt-0.5 flex-shrink-0" />
                  <span>Consider tax implications before selling positions with gains</span>
                </li>
                <li className="flex items-start space-x-2">
                  <ArrowRight className="h-4 w-4 mt-0.5 flex-shrink-0" />
                  <span>Use new contributions to rebalance without triggering taxes</span>
                </li>
                <li className="flex items-start space-x-2">
                  <ArrowRight className="h-4 w-4 mt-0.5 flex-shrink-0" />
                  <span>Consider gradual rebalancing for large deviations</span>
                </li>
                <li className="flex items-start space-x-2">
                  <ArrowRight className="h-4 w-4 mt-0.5 flex-shrink-0" />
                  <span>Review transaction costs before executing trades</span>
                </li>
              </ul>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
