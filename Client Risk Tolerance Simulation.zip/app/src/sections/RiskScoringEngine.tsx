import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Slider } from '@/components/ui/slider';
import { Progress } from '@/components/ui/progress';
import { 
  Calculator, 
  Settings, 
  TrendingUp, 
  TrendingDown,
  Activity,
  Brain,
  Briefcase,
  Shield,
  CheckCircle
} from 'lucide-react';
import type { RiskProfile, DynamicRiskScore } from '@/types';
import type { ScoringWeights, MarketCondition } from '@/data/riskScoring';
import { 
  calculateDynamicRiskScore, 
  getRiskCategory, 
  getRecommendedAllocation,
  defaultWeights
} from '@/data/riskScoring';
import { getClientBehavioralData } from '@/data/sampleClients';
import { 
  PieChart, 
  Pie, 
  Cell, 
  ResponsiveContainer,
  Tooltip
} from 'recharts';

interface RiskScoringEngineProps {
  client: RiskProfile;
}

export default function RiskScoringEngine({ client }: RiskScoringEngineProps) {
  const [weights, setWeights] = useState<ScoringWeights>(defaultWeights);
  const [marketCondition, setMarketCondition] = useState<MarketCondition>('stable');
  
  const behavioralData = getClientBehavioralData(client.id);
  
  const dynamicScore = calculateDynamicRiskScore(
    client,
    behavioralData,
    [],
    [],
    marketCondition,
    weights
  );

  const riskCategory = getRiskCategory(dynamicScore.overallScore);
  const recommendedAllocation = getRecommendedAllocation(dynamicScore.overallScore);

  const allocationData = Object.entries(recommendedAllocation).map(([key, value]) => ({
    name: key.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase()),
    value
  }));

  const COLORS = ['#3b82f6', '#10b981', '#f59e0b', '#ef4444', '#8b5cf6', '#ec4899', '#06b6d4', '#84cc16'];

  const componentData = [
    { name: 'Financial Capacity', value: dynamicScore.components.financialCapacity, weight: weights.financialCapacity },
    { name: 'Risk Attitude', value: dynamicScore.components.riskAttitude, weight: weights.riskAttitude },
    { name: 'Risk Knowledge', value: dynamicScore.components.riskKnowledge, weight: weights.riskKnowledge },
    { name: 'Behavioral Consistency', value: dynamicScore.components.behavioralConsistency, weight: weights.behavioralConsistency },
  ];

  const getScoreColor = (score: number) => {
    if (score >= 70) return 'text-green-600';
    if (score >= 50) return 'text-blue-600';
    if (score >= 35) return 'text-amber-600';
    return 'text-red-600';
  };

  const getScoreBgColor = (score: number) => {
    if (score >= 70) return 'bg-green-500';
    if (score >= 50) return 'bg-blue-500';
    if (score >= 35) return 'bg-amber-500';
    return 'bg-red-500';
  };

  const getActionColor = (action: DynamicRiskScore['recommendedAction']) => {
    switch (action) {
      case 'maintain': return 'text-green-600 bg-green-50';
      case 'review_recommended': return 'text-blue-600 bg-blue-50';
      case 'rebalance_required': return 'text-amber-600 bg-amber-50';
      case 'immediate_attention': return 'text-red-600 bg-red-50';
    }
  };

  const resetWeights = () => setWeights(defaultWeights);

  return (
    <div className="space-y-6">
      {/* Score Overview */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card className="md:col-span-2">
          <CardHeader>
            <CardTitle className="flex items-center">
              <Calculator className="h-6 w-6 mr-2 text-blue-500" />
              Dynamic Risk Score
            </CardTitle>
            <CardDescription>
              Real-time risk tolerance calculation based on multiple weighted factors
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex items-center justify-between">
              <div className="text-center flex-1">
                <p className="text-sm text-slate-500 mb-2">Overall Score</p>
                <p className={`text-6xl font-bold ${getScoreColor(dynamicScore.overallScore)}`}>
                  {Math.round(dynamicScore.overallScore)}
                </p>
                <Badge className={`mt-2 ${getScoreBgColor(dynamicScore.overallScore)} text-white`}>
                  {riskCategory}
                </Badge>
              </div>
              <div className="h-24 w-px bg-slate-200" />
              <div className="text-center flex-1">
                <p className="text-sm text-slate-500 mb-2">Confidence</p>
                <p className="text-4xl font-bold text-slate-700">
                  {Math.round(dynamicScore.confidence)}%
                </p>
                <p className="text-xs text-slate-500 mt-2">
                  Based on data quality and history
                </p>
              </div>
              <div className="h-24 w-px bg-slate-200" />
              <div className="text-center flex-1">
                <p className="text-sm text-slate-500 mb-2">Trend</p>
                <div className="flex items-center justify-center">
                  {dynamicScore.trend === 'increasing' ? (
                    <TrendingUp className="h-10 w-10 text-green-500" />
                  ) : dynamicScore.trend === 'decreasing' ? (
                    <TrendingDown className="h-10 w-10 text-red-500" />
                  ) : (
                    <Activity className="h-10 w-10 text-slate-400" />
                  )}
                </div>
                <p className="text-xs text-slate-500 mt-2 capitalize">
                  {dynamicScore.trend.replace('_', ' ')}
                  {dynamicScore.trendMagnitude !== 0 && ` (${dynamicScore.trendMagnitude > 0 ? '+' : ''}${Math.round(dynamicScore.trendMagnitude)})`}
                </p>
              </div>
            </div>

            <div className="mt-6 p-4 bg-slate-50 rounded-lg">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-slate-600">Recommended Action</p>
                  <p className={`text-lg font-semibold mt-1 px-3 py-1 rounded-full inline-block ${getActionColor(dynamicScore.recommendedAction)}`}>
                    {dynamicScore.recommendedAction.replace('_', ' ').toUpperCase()}
                  </p>
                </div>
                <div className="text-right">
                  <p className="text-sm text-slate-600">Last Updated</p>
                  <p className="text-sm font-medium">
                    {dynamicScore.lastUpdated.toLocaleString()}
                  </p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-lg">Market Condition</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              {(['bull', 'bear', 'volatile', 'stable'] as MarketCondition[]).map(condition => (
                <button
                  key={condition}
                  onClick={() => setMarketCondition(condition)}
                  className={`w-full p-3 rounded-lg text-left capitalize transition-all ${
                    marketCondition === condition
                      ? 'bg-blue-50 border-2 border-blue-500'
                      : 'bg-slate-50 border-2 border-transparent hover:bg-slate-100'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <span className="font-medium">{condition}</span>
                    {marketCondition === condition && <CheckCircle className="h-5 w-5 text-blue-500" />}
                  </div>
                </button>
              ))}
            </div>
            <div className="mt-4 p-3 bg-amber-50 rounded-lg">
              <p className="text-xs text-amber-800">
                Market conditions affect risk attitude multiplier
              </p>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Component Breakdown */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle className="text-lg flex items-center">
              <Brain className="h-5 w-5 mr-2 text-purple-500" />
              Score Components
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {componentData.map((component, index) => (
                <div key={index}>
                  <div className="flex justify-between items-center mb-1">
                    <span className="text-sm text-slate-700">{component.name}</span>
                    <div className="flex items-center space-x-2">
                      <span className={`text-sm font-semibold ${getScoreColor(component.value)}`}>
                        {Math.round(component.value)}
                      </span>
                      <Badge variant="outline" className="text-xs">
                        {Math.round(component.weight * 100)}%
                      </Badge>
                    </div>
                  </div>
                  <Progress value={component.value} className="h-2" />
                </div>
              ))}

              <div className="mt-4 pt-4 border-t border-slate-100">
                <div className="flex justify-between items-center mb-1">
                  <span className="text-sm text-slate-700">Life Event Impact</span>
                  <span className={`text-sm font-semibold ${
                    dynamicScore.components.lifeEventImpact >= 0 ? 'text-green-600' : 'text-red-600'
                  }`}>
                    {dynamicScore.components.lifeEventImpact > 0 ? '+' : ''}
                    {dynamicScore.components.lifeEventImpact}
                  </span>
                </div>
                <Progress 
                  value={50 + dynamicScore.components.lifeEventImpact * 2} 
                  className="h-2"
                />
              </div>

              <div className="flex justify-between items-center mb-1">
                <span className="text-sm text-slate-700">Market Condition Impact</span>
                <span className={`text-sm font-semibold ${
                  dynamicScore.components.marketConditionImpact >= 0 ? 'text-green-600' : 'text-red-600'
                }`}>
                  {dynamicScore.components.marketConditionImpact > 0 ? '+' : ''}
                  {dynamicScore.components.marketConditionImpact}
                </span>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-lg flex items-center">
              <Briefcase className="h-5 w-5 mr-2 text-green-500" />
              Recommended Asset Allocation
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={200}>
              <PieChart>
                <Pie
                  data={allocationData}
                  cx="50%"
                  cy="50%"
                  innerRadius={40}
                  outerRadius={80}
                  paddingAngle={2}
                  dataKey="value"
                >
                  {allocationData.map((_, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
            <div className="grid grid-cols-2 gap-2 mt-4">
              {allocationData.slice(0, 4).map((item, index) => (
                <div key={index} className="flex items-center space-x-2">
                  <div 
                    className="w-3 h-3 rounded-full" 
                    style={{ backgroundColor: COLORS[index % COLORS.length] }}
                  />
                  <span className="text-xs text-slate-600">{item.name}: {item.value}%</span>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Advanced Settings */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="text-lg flex items-center">
              <Settings className="h-5 w-5 mr-2 text-slate-500" />
              Scoring Weights Configuration
            </CardTitle>
            <Button variant="outline" size="sm" onClick={resetWeights}>
              Reset to Default
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            <div>
              <label className="text-sm font-medium text-slate-700 flex items-center justify-between">
                <span>Financial Capacity</span>
                <span className="text-blue-600">{Math.round(weights.financialCapacity * 100)}%</span>
              </label>
              <Slider
                value={[weights.financialCapacity * 100]}
                onValueChange={(value) => setWeights({ ...weights, financialCapacity: value[0] / 100 })}
                max={50}
                min={10}
                step={5}
                className="mt-2"
              />
              <p className="text-xs text-slate-500 mt-1">
                Income, savings, debt, time horizon
              </p>
            </div>

            <div>
              <label className="text-sm font-medium text-slate-700 flex items-center justify-between">
                <span>Risk Attitude</span>
                <span className="text-purple-600">{Math.round(weights.riskAttitude * 100)}%</span>
              </label>
              <Slider
                value={[weights.riskAttitude * 100]}
                onValueChange={(value) => setWeights({ ...weights, riskAttitude: value[0] / 100 })}
                max={50}
                min={10}
                step={5}
                className="mt-2"
              />
              <p className="text-xs text-slate-500 mt-1">
                Emotional comfort with uncertainty
              </p>
            </div>

            <div>
              <label className="text-sm font-medium text-slate-700 flex items-center justify-between">
                <span>Risk Knowledge</span>
                <span className="text-green-600">{Math.round(weights.riskKnowledge * 100)}%</span>
              </label>
              <Slider
                value={[weights.riskKnowledge * 100]}
                onValueChange={(value) => setWeights({ ...weights, riskKnowledge: value[0] / 100 })}
                max={30}
                min={5}
                step={5}
                className="mt-2"
              />
              <p className="text-xs text-slate-500 mt-1">
                Financial literacy and experience
              </p>
            </div>

            <div>
              <label className="text-sm font-medium text-slate-700 flex items-center justify-between">
                <span>Behavioral Consistency</span>
                <span className="text-amber-600">{Math.round(weights.behavioralConsistency * 100)}%</span>
              </label>
              <Slider
                value={[weights.behavioralConsistency * 100]}
                onValueChange={(value) => setWeights({ ...weights, behavioralConsistency: value[0] / 100 })}
                max={40}
                min={10}
                step={5}
                className="mt-2"
              />
              <p className="text-xs text-slate-500 mt-1">
                Stated vs revealed preferences
              </p>
            </div>

            <div>
              <label className="text-sm font-medium text-slate-700 flex items-center justify-between">
                <span>Life Event Impact</span>
                <span className="text-red-600">{Math.round(weights.lifeEventImpact * 100)}%</span>
              </label>
              <Slider
                value={[weights.lifeEventImpact * 100]}
                onValueChange={(value) => setWeights({ ...weights, lifeEventImpact: value[0] / 100 })}
                max={20}
                min={0}
                step={5}
                className="mt-2"
              />
              <p className="text-xs text-slate-500 mt-1">
                Recent life events effect
              </p>
            </div>

            <div>
              <label className="text-sm font-medium text-slate-700 flex items-center justify-between">
                <span>Market Conditions</span>
                <span className="text-indigo-600">{Math.round(weights.marketConditionImpact * 100)}%</span>
              </label>
              <Slider
                value={[weights.marketConditionImpact * 100]}
                onValueChange={(value) => setWeights({ ...weights, marketConditionImpact: value[0] / 100 })}
                max={15}
                min={0}
                step={5}
                className="mt-2"
              />
              <p className="text-xs text-slate-500 mt-1">
                Current market environment
              </p>
            </div>
          </div>

          <div className="mt-6 p-4 bg-blue-50 rounded-lg">
            <h4 className="font-semibold text-blue-900 mb-2">Weight Sum Validation</h4>
            <div className="flex items-center space-x-4">
              <Progress 
                value={Object.values(weights).reduce((a, b) => a + b, 0) * 100} 
                className="flex-1 h-3"
              />
              <span className={`font-semibold ${
                Math.abs(Object.values(weights).reduce((a, b) => a + b, 0) - 1) < 0.01
                  ? 'text-green-600'
                  : 'text-red-600'
              }`}>
                {Math.round(Object.values(weights).reduce((a, b) => a + b, 0) * 100)}%
              </span>
            </div>
            {Math.abs(Object.values(weights).reduce((a, b) => a + b, 0) - 1) >= 0.01 && (
              <p className="text-sm text-red-600 mt-2">
                Warning: Weights must sum to 100%
              </p>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Methodology Info */}
      <Card>
        <CardHeader>
          <CardTitle className="text-lg flex items-center">
            <Shield className="h-5 w-5 mr-2 text-indigo-500" />
            Scoring Methodology
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="bg-slate-50 p-4 rounded-lg">
              <h4 className="font-semibold text-slate-900 mb-2">Weighted Scoring Model</h4>
              <p className="text-sm text-slate-600">
                Combines multiple risk factors using configurable weights to produce a comprehensive 
                risk tolerance score from 0-100.
              </p>
            </div>
            <div className="bg-slate-50 p-4 rounded-lg">
              <h4 className="font-semibold text-slate-900 mb-2">Dynamic Adjustments</h4>
              <p className="text-sm text-slate-600">
                Scores adjust in real-time based on life events, market conditions, and behavioral 
                patterns with appropriate decay functions.
              </p>
            </div>
            <div className="bg-slate-50 p-4 rounded-lg">
              <h4 className="font-semibold text-slate-900 mb-2">Confidence Scoring</h4>
              <p className="text-sm text-slate-600">
                Each score includes a confidence metric based on data quality, assessment history, 
                and behavioral consistency.
              </p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
