import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { 
  Eye, 
  TrendingUp, 
  TrendingDown, 
  Clock, 
  AlertTriangle,
  Rocket,
  RefreshCw,
  Calendar,
  Activity,
  Brain,
  BarChart3
} from 'lucide-react';
import type { RiskProfile, EmotionalState } from '@/types';
import { 
  behavioralIndicatorConfigs, 
  calculateBehavioralRiskScore,
  getEmotionalStateDescription,
  generateSampleBehavioralMetrics
} from '@/data/behavioralIndicators';
import { getClientBehavioralData } from '@/data/sampleClients';
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  RadarChart,
  PolarGrid,
  PolarAngleAxis,
  PolarRadiusAxis,
  Radar,
  Legend
} from 'recharts';

interface BehavioralDashboardProps {
  client: RiskProfile;
}

export default function BehavioralDashboard({ client }: BehavioralDashboardProps) {
  const [activeTab, setActiveTab] = useState('overview');
  const behavioralData = getClientBehavioralData(client.id);
  const sampleMetrics = generateSampleBehavioralMetrics(12);

  const behavioralRiskScore = calculateBehavioralRiskScore(behavioralData);

  const getIndicatorStatus = (config: typeof behavioralIndicatorConfigs[0], value: number) => {
    if (value >= config.criticalThreshold) return { label: 'Critical', color: 'text-red-600', bg: 'bg-red-100' };
    if (value >= config.warningThreshold) return { label: 'Warning', color: 'text-amber-600', bg: 'bg-amber-100' };
    if (value < config.normalRange[0]) return { label: 'Low', color: 'text-blue-600', bg: 'bg-blue-100' };
    return { label: 'Normal', color: 'text-green-600', bg: 'bg-green-100' };
  };

  const getEmotionalIcon = (state: EmotionalState) => {
    const icons: Record<EmotionalState, React.ReactNode> = {
      calm: <Activity className="h-5 w-5 text-green-500" />,
      anxious: <AlertTriangle className="h-5 w-5 text-amber-500" />,
      excited: <Rocket className="h-5 w-5 text-purple-500" />,
      fearful: <TrendingDown className="h-5 w-5 text-red-500" />,
      overconfident: <TrendingUp className="h-5 w-5 text-blue-500" />,
      indifferent: <Clock className="h-5 w-5 text-slate-500" />
    };
    return icons[state];
  };

  // Prepare chart data
  const loginData = sampleMetrics.map(m => ({
    month: m.date.toLocaleDateString('en-US', { month: 'short' }),
    logins: m.loginCount,
    views: m.portfolioViews,
    trades: m.tradesExecuted
  }));

  const radarData = [
    { subject: 'Checking Freq', A: Math.min(100, behavioralData.portfolioCheckingFrequency * 10), fullMark: 100 },
    { subject: 'Trading Discipline', A: 100 - (behavioralData.tradingFrequency * 10), fullMark: 100 },
    { subject: 'Holding Period', A: Math.min(100, behavioralData.averageHoldingPeriod / 10), fullMark: 100 },
    { subject: 'Contribution Consistency', A: behavioralData.contributionConsistency, fullMark: 100 },
    { subject: 'Panic Resistance', A: 100 - behavioralData.panicSellTendency, fullMark: 100 },
    { subject: 'FOMO Resistance', A: 100 - behavioralData.fomoTendency, fullMark: 100 },
    { subject: 'Rebalancing Discipline', A: behavioralData.rebalancingDiscipline, fullMark: 100 },
  ];

  return (
    <div className="space-y-6">
      {/* Header Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card className="bg-gradient-to-br from-blue-50 to-blue-100">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-blue-600 font-medium">Behavioral Risk Score</p>
                <p className={`text-2xl font-bold ${
                  behavioralRiskScore > 70 ? 'text-red-700' :
                  behavioralRiskScore > 50 ? 'text-amber-700' :
                  'text-blue-700'
                }`}>
                  {behavioralRiskScore}
                </p>
              </div>
              <Brain className="h-8 w-8 text-blue-500" />
            </div>
            <p className="text-xs text-blue-600 mt-2">
              {behavioralRiskScore > 70 ? 'High behavioral risk detected' :
               behavioralRiskScore > 50 ? 'Moderate behavioral concerns' :
               'Healthy behavioral patterns'}
            </p>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-green-50 to-green-100">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-green-600 font-medium">Portfolio Checks/Week</p>
                <p className="text-2xl font-bold text-green-700">
                  {behavioralData.portfolioCheckingFrequency}
                </p>
              </div>
              <Eye className="h-8 w-8 text-green-500" />
            </div>
            <p className="text-xs text-green-600 mt-2">
              {behavioralData.portfolioCheckingFrequency > 5 ? 'Excessive checking detected' :
               behavioralData.portfolioCheckingFrequency < 1 ? 'Low engagement' :
               'Healthy monitoring frequency'}
            </p>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-purple-50 to-purple-100">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-purple-600 font-medium">Avg Holding Period</p>
                <p className="text-2xl font-bold text-purple-700">
                  {Math.round(behavioralData.averageHoldingPeriod / 365 * 10) / 10}y
                </p>
              </div>
              <Clock className="h-8 w-8 text-purple-500" />
            </div>
            <p className="text-xs text-purple-600 mt-2">
              {behavioralData.averageHoldingPeriod < 180 ? 'Short-term trading pattern' :
               behavioralData.averageHoldingPeriod > 730 ? 'Long-term investor' :
               'Medium-term holding pattern'}
            </p>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-amber-50 to-amber-100">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-amber-600 font-medium">Trades/Month</p>
                <p className="text-2xl font-bold text-amber-700">
                  {behavioralData.tradingFrequency}
                </p>
              </div>
              <TrendingUp className="h-8 w-8 text-amber-500" />
            </div>
            <p className="text-xs text-amber-600 mt-2">
              {behavioralData.tradingFrequency > 5 ? 'High trading activity' :
               behavioralData.tradingFrequency === 0 ? 'No recent trades' :
               'Moderate trading activity'}
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Main Content Tabs */}
      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid grid-cols-4 gap-4">
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="indicators">Key Indicators</TabsTrigger>
          <TabsTrigger value="patterns">Behavioral Patterns</TabsTrigger>
          <TabsTrigger value="history">Activity History</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Behavioral Radar */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg flex items-center">
                  <BarChart3 className="h-5 w-5 mr-2 text-purple-500" />
                  Behavioral Profile
                </CardTitle>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={250}>
                  <RadarChart data={radarData}>
                    <PolarGrid />
                    <PolarAngleAxis dataKey="subject" tick={{ fontSize: 10 }} />
                    <PolarRadiusAxis angle={30} domain={[0, 100]} tick={false} />
                    <Radar
                      name={client.clientName}
                      dataKey="A"
                      stroke="#8b5cf6"
                      fill="#8b5cf6"
                      fillOpacity={0.3}
                    />
                  </RadarChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            {/* Emotional State */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg flex items-center">
                  <Brain className="h-5 w-5 mr-2 text-blue-500" />
                  Emotional State Analysis
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {sampleMetrics.slice(-3).map((metric, index) => (
                    <div key={index} className="flex items-center justify-between p-3 bg-slate-50 rounded-lg">
                      <div className="flex items-center space-x-3">
                        {metric.emotionalState && getEmotionalIcon(metric.emotionalState)}
                        <div>
                          <p className="font-medium text-sm capitalize">{metric.emotionalState}</p>
                          <p className="text-xs text-slate-500">
                            {metric.emotionalState && getEmotionalStateDescription(metric.emotionalState)}
                          </p>
                        </div>
                      </div>
                      <span className="text-xs text-slate-400">
                        {metric.date.toLocaleDateString('en-US', { month: 'short' })}
                      </span>
                    </div>
                  ))}
                </div>

                <div className="mt-4 p-4 bg-blue-50 rounded-lg">
                  <h4 className="font-semibold text-blue-900 mb-2">Behavioral Insights</h4>
                  <ul className="space-y-2 text-sm text-blue-800">
                    <li className="flex items-start space-x-2">
                      <div className="w-1.5 h-1.5 rounded-full bg-blue-500 mt-1.5" />
                      <span>
                        {behavioralData.loginDuringVolatility 
                          ? 'Client logs in during volatile periods - may need reassurance'
                          : 'Client maintains composure during market volatility'}
                      </span>
                    </li>
                    <li className="flex items-start space-x-2">
                      <div className="w-1.5 h-1.5 rounded-full bg-blue-500 mt-1.5" />
                      <span>
                        {behavioralData.portfolioCheckingFrequency > 5
                          ? 'High portfolio checking frequency suggests anxiety'
                          : 'Healthy portfolio monitoring habits observed'}
                      </span>
                    </li>
                    <li className="flex items-start space-x-2">
                      <div className="w-1.5 h-1.5 rounded-full bg-blue-500 mt-1.5" />
                      <span>
                        {behavioralData.panicSellTendency > 50
                          ? 'Elevated panic sell tendency - proactive outreach recommended'
                          : 'Good emotional control during downturns'}
                      </span>
                    </li>
                  </ul>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="indicators">
          <Card>
            <CardHeader>
              <CardTitle>Detailed Behavioral Indicators</CardTitle>
              <CardDescription>
                Comprehensive analysis of client behavior patterns
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                {behavioralIndicatorConfigs.map(config => {
                  const value = behavioralData[config.id as keyof typeof behavioralData] as number;
                  const status = getIndicatorStatus(config, value);
                  
                  return (
                    <div key={config.id} className="border-b border-slate-100 pb-4 last:border-0">
                      <div className="flex items-start justify-between mb-2">
                        <div>
                          <h4 className="font-semibold text-slate-900">{config.name}</h4>
                          <p className="text-sm text-slate-500">{config.description}</p>
                        </div>
                        <div className="flex items-center space-x-2">
                          <span className={`text-lg font-bold ${status.color}`}>{value}</span>
                          <Badge className={`${status.bg} ${status.color} border-0`}>
                            {status.label}
                          </Badge>
                        </div>
                      </div>
                      <Progress 
                        value={Math.min(100, (value / config.criticalThreshold) * 100)} 
                        className="h-2"
                      />
                      <p className="text-xs text-slate-500 mt-2">
                        {value > config.warningThreshold 
                          ? config.interpretation.high 
                          : value < config.normalRange[0]
                          ? config.interpretation.low
                          : config.interpretation.normal}
                      </p>
                    </div>
                  );
                })}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="patterns">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Behavioral Biases Detected</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {behavioralData.panicSellTendency > 40 && (
                    <div className="p-4 bg-red-50 rounded-lg border-l-4 border-red-500">
                      <h4 className="font-semibold text-red-900">Loss Aversion</h4>
                      <p className="text-sm text-red-700 mt-1">
                        High tendency to sell during market downturns. May benefit from education on 
                        long-term investing and market cycles.
                      </p>
                      <div className="mt-2">
                        <span className="text-xs text-red-600">Severity: </span>
                        <Progress value={behavioralData.panicSellTendency} className="h-1 mt-1" />
                      </div>
                    </div>
                  )}

                  {behavioralData.fomoTendency > 40 && (
                    <div className="p-4 bg-amber-50 rounded-lg border-l-4 border-amber-500">
                      <h4 className="font-semibold text-amber-900">FOMO (Fear of Missing Out)</h4>
                      <p className="text-sm text-amber-700 mt-1">
                        Tendency to chase performance during market rallies. May need guidance on 
                        disciplined investment approach.
                      </p>
                      <div className="mt-2">
                        <span className="text-xs text-amber-600">Severity: </span>
                        <Progress value={behavioralData.fomoTendency} className="h-1 mt-1" />
                      </div>
                    </div>
                  )}

                  {behavioralData.portfolioCheckingFrequency > 7 && (
                    <div className="p-4 bg-blue-50 rounded-lg border-l-4 border-blue-500">
                      <h4 className="font-semibold text-blue-900">Myopic Loss Aversion</h4>
                      <p className="text-sm text-blue-700 mt-1">
                        Excessive portfolio monitoring may lead to short-term thinking. 
                        Consider recommending less frequent check-ins.
                      </p>
                    </div>
                  )}

                  {behavioralData.tradingFrequency > 5 && (
                    <div className="p-4 bg-purple-50 rounded-lg border-l-4 border-purple-500">
                      <h4 className="font-semibold text-purple-900">Overtrading</h4>
                      <p className="text-sm text-purple-700 mt-1">
                        High trading frequency may indicate overconfidence or reaction to short-term 
                        market movements.
                      </p>
                    </div>
                  )}

                  {behavioralRiskScore <= 50 && (
                    <div className="p-4 bg-green-50 rounded-lg border-l-4 border-green-500">
                      <h4 className="font-semibold text-green-900">Well-Balanced Behavior</h4>
                      <p className="text-sm text-green-700 mt-1">
                        Client demonstrates healthy investment behaviors with good emotional control 
                        and disciplined approach.
                      </p>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Recommended Interventions</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {behavioralData.panicSellTendency > 40 && (
                    <div className="flex items-start space-x-3 p-3 bg-slate-50 rounded-lg">
                      <div className="w-8 h-8 rounded-full bg-red-100 flex items-center justify-center flex-shrink-0">
                        <AlertTriangle className="h-4 w-4 text-red-600" />
                      </div>
                      <div>
                        <h4 className="font-medium text-slate-900">Proactive Outreach During Volatility</h4>
                        <p className="text-sm text-slate-600">
                          Schedule check-in calls during market downturns to provide reassurance 
                          and prevent panic selling.
                        </p>
                      </div>
                    </div>
                  )}

                  {behavioralData.portfolioCheckingFrequency > 7 && (
                    <div className="flex items-start space-x-3 p-3 bg-slate-50 rounded-lg">
                      <div className="w-8 h-8 rounded-full bg-blue-100 flex items-center justify-center flex-shrink-0">
                        <Eye className="h-4 w-4 text-blue-600" />
                      </div>
                      <div>
                        <h4 className="font-medium text-slate-900">Educate on Monitoring Frequency</h4>
                        <p className="text-sm text-slate-600">
                          Explain the benefits of less frequent portfolio checking to reduce 
                          anxiety and impulsive decisions.
                        </p>
                      </div>
                    </div>
                  )}

                  {behavioralData.fomoTendency > 40 && (
                    <div className="flex items-start space-x-3 p-3 bg-slate-50 rounded-lg">
                      <div className="w-8 h-8 rounded-full bg-amber-100 flex items-center justify-center flex-shrink-0">
                        <Rocket className="h-4 w-4 text-amber-600" />
                      </div>
                      <div>
                        <h4 className="font-medium text-slate-900">Goal-Based Investing Education</h4>
                        <p className="text-sm text-slate-600">
                          Reinforce long-term goals and the dangers of chasing performance 
                          during market rallies.
                        </p>
                      </div>
                    </div>
                  )}

                  {behavioralData.rebalancingDiscipline < 60 && (
                    <div className="flex items-start space-x-3 p-3 bg-slate-50 rounded-lg">
                      <div className="w-8 h-8 rounded-full bg-purple-100 flex items-center justify-center flex-shrink-0">
                        <RefreshCw className="h-4 w-4 text-purple-600" />
                      </div>
                      <div>
                        <h4 className="font-medium text-slate-900">Automated Rebalancing</h4>
                        <p className="text-sm text-slate-600">
                          Set up automatic rebalancing to maintain target allocation without 
                          requiring client intervention.
                        </p>
                      </div>
                    </div>
                  )}

                  <div className="flex items-start space-x-3 p-3 bg-slate-50 rounded-lg">
                    <div className="w-8 h-8 rounded-full bg-green-100 flex items-center justify-center flex-shrink-0">
                      <Calendar className="h-4 w-4 text-green-600" />
                    </div>
                    <div>
                      <h4 className="font-medium text-slate-900">Regular Review Schedule</h4>
                      <p className="text-sm text-slate-600">
                        Establish quarterly review meetings to discuss portfolio performance 
                        and address any concerns proactively.
                      </p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="history">
          <Card>
            <CardHeader>
              <CardTitle>12-Month Activity History</CardTitle>
              <CardDescription>
                Historical view of client engagement and behavior patterns
              </CardDescription>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <BarChart data={loginData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="month" />
                  <YAxis />
                  <Tooltip />
                  <Legend />
                  <Bar dataKey="logins" name="Logins" fill="#3b82f6" />
                  <Bar dataKey="views" name="Portfolio Views" fill="#8b5cf6" />
                  <Bar dataKey="trades" name="Trades" fill="#10b981" />
                </BarChart>
              </ResponsiveContainer>

              <div className="mt-6">
                <h4 className="font-semibold text-slate-900 mb-4">Monthly Activity Details</h4>
                <div className="overflow-x-auto">
                  <table className="w-full text-sm">
                    <thead>
                      <tr className="border-b border-slate-200">
                        <th className="text-left py-2 px-4">Month</th>
                        <th className="text-center py-2 px-4">Logins</th>
                        <th className="text-center py-2 px-4">Portfolio Views</th>
                        <th className="text-center py-2 px-4">Trades</th>
                        <th className="text-center py-2 px-4">Support Calls</th>
                        <th className="text-left py-2 px-4">Emotional State</th>
                      </tr>
                    </thead>
                    <tbody>
                      {sampleMetrics.slice(-6).reverse().map((metric, index) => (
                        <tr key={index} className="border-b border-slate-100">
                          <td className="py-2 px-4">
                            {metric.date.toLocaleDateString('en-US', { month: 'long', year: 'numeric' })}
                          </td>
                          <td className="text-center py-2 px-4">{metric.loginCount}</td>
                          <td className="text-center py-2 px-4">{metric.portfolioViews}</td>
                          <td className="text-center py-2 px-4">{metric.tradesExecuted}</td>
                          <td className="text-center py-2 px-4">{metric.supportCalls}</td>
                          <td className="py-2 px-4">
                            {metric.emotionalState && (
                              <div className="flex items-center space-x-2">
                                {getEmotionalIcon(metric.emotionalState)}
                                <span className="capitalize">{metric.emotionalState}</span>
                              </div>
                            )}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
