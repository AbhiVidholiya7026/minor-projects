import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { 
  AlertTriangle, 
  Bell, 
  CheckCircle, 
  Clock,
  Heart,
  TrendingDown,
  TrendingUp,
  Brain,
  X,
  Filter
} from 'lucide-react';
import type { Alert } from '@/types';
import { sampleAlerts, sampleClients } from '@/data/sampleClients';

export default function AlertPanel() {
  const [alerts, setAlerts] = useState<Alert[]>(sampleAlerts);
  const [filter, setFilter] = useState<'all' | 'life_event' | 'behavioral_change' | 'market_impact' | 'misalignment'>('all');
  const [severityFilter, setSeverityFilter] = useState<'all' | 'low' | 'medium' | 'high' | 'critical'>('all');

  const filteredAlerts = alerts.filter(alert => {
    const typeMatch = filter === 'all' || alert.type === filter;
    const severityMatch = severityFilter === 'all' || alert.severity === severityFilter;
    return typeMatch && severityMatch;
  });

  const acknowledgeAlert = (alertId: string) => {
    setAlerts(alerts.map(alert => 
      alert.id === alertId ? { ...alert, acknowledged: true } : alert
    ));
  };

  const dismissAlert = (alertId: string) => {
    setAlerts(alerts.filter(alert => alert.id !== alertId));
  };

  const getAlertIcon = (type: Alert['type']) => {
    switch (type) {
      case 'life_event':
        return <Heart className="h-5 w-5 text-pink-500" />;
      case 'behavioral_change':
        return <Brain className="h-5 w-5 text-purple-500" />;
      case 'market_impact':
        return <TrendingDown className="h-5 w-5 text-red-500" />;
      case 'misalignment':
        return <AlertTriangle className="h-5 w-5 text-amber-500" />;
    }
  };

  const getSeverityColor = (severity: Alert['severity']) => {
    switch (severity) {
      case 'critical':
        return 'bg-red-100 text-red-800 border-red-300';
      case 'high':
        return 'bg-orange-100 text-orange-800 border-orange-300';
      case 'medium':
        return 'bg-amber-100 text-amber-800 border-amber-300';
      case 'low':
        return 'bg-blue-100 text-blue-800 border-blue-300';
    }
  };

  const getClientName = (clientId: string) => {
    const client = sampleClients.find(c => c.id === clientId);
    return client?.clientName || 'Unknown Client';
  };

  const stats = {
    total: alerts.length,
    unacknowledged: alerts.filter(a => !a.acknowledged).length,
    critical: alerts.filter(a => a.severity === 'critical').length,
    high: alerts.filter(a => a.severity === 'high').length
  };

  return (
    <div className="space-y-6">
      {/* Stats Overview */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card className="bg-gradient-to-br from-blue-50 to-blue-100">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-blue-600 font-medium">Total Alerts</p>
                <p className="text-2xl font-bold text-blue-900">{stats.total}</p>
              </div>
              <Bell className="h-8 w-8 text-blue-500" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-amber-50 to-amber-100">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-amber-600 font-medium">Pending</p>
                <p className="text-2xl font-bold text-amber-900">{stats.unacknowledged}</p>
              </div>
              <Clock className="h-8 w-8 text-amber-500" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-red-50 to-red-100">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-red-600 font-medium">Critical</p>
                <p className="text-2xl font-bold text-red-900">{stats.critical}</p>
              </div>
              <AlertTriangle className="h-8 w-8 text-red-500" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-orange-50 to-orange-100">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-orange-600 font-medium">High Priority</p>
                <p className="text-2xl font-bold text-orange-900">{stats.high}</p>
              </div>
              <TrendingUp className="h-8 w-8 text-orange-500" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Filters */}
      <Card>
        <CardHeader>
          <CardTitle className="text-lg flex items-center">
            <Filter className="h-5 w-5 mr-2 text-slate-500" />
            Filter Alerts
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex flex-wrap gap-4">
            <div>
              <span className="text-sm text-slate-600 mr-2">Type:</span>
              <div className="inline-flex flex-wrap gap-2">
                {(['all', 'life_event', 'behavioral_change', 'market_impact', 'misalignment'] as const).map(type => (
                  <button
                    key={type}
                    onClick={() => setFilter(type)}
                    className={`px-3 py-1 rounded-full text-sm transition-all ${
                      filter === type
                        ? 'bg-blue-500 text-white'
                        : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                    }`}
                  >
                    {type.replace('_', ' ').replace(/\b\w/g, l => l.toUpperCase())}
                  </button>
                ))}
              </div>
            </div>
            <div>
              <span className="text-sm text-slate-600 mr-2">Severity:</span>
              <div className="inline-flex flex-wrap gap-2">
                {(['all', 'low', 'medium', 'high', 'critical'] as const).map(sev => (
                  <button
                    key={sev}
                    onClick={() => setSeverityFilter(sev)}
                    className={`px-3 py-1 rounded-full text-sm transition-all ${
                      severityFilter === sev
                        ? 'bg-red-500 text-white'
                        : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                    }`}
                  >
                    {sev.charAt(0).toUpperCase() + sev.slice(1)}
                  </button>
                ))}
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Alerts List */}
      <Card>
        <CardHeader>
          <CardTitle>Active Alerts</CardTitle>
          <CardDescription>
            {filteredAlerts.length} alert{filteredAlerts.length !== 1 ? 's' : ''} matching your filters
          </CardDescription>
        </CardHeader>
        <CardContent>
          {filteredAlerts.length === 0 ? (
            <div className="text-center py-12">
              <CheckCircle className="h-16 w-16 text-green-500 mx-auto mb-4" />
              <h3 className="text-lg font-semibold text-slate-900">No Alerts Found</h3>
              <p className="text-slate-600">All caught up! No alerts match your current filters.</p>
            </div>
          ) : (
            <div className="space-y-4">
              {filteredAlerts.map(alert => (
                <div 
                  key={alert.id} 
                  className={`p-4 rounded-lg border transition-all ${
                    alert.acknowledged 
                      ? 'bg-slate-50 border-slate-200 opacity-60' 
                      : 'bg-white border-slate-200 shadow-sm'
                  }`}
                >
                  <div className="flex items-start justify-between">
                    <div className="flex items-start space-x-4">
                      <div className={`p-2 rounded-lg ${
                        alert.acknowledged ? 'bg-slate-100' : 'bg-slate-50'
                      }`}>
                        {getAlertIcon(alert.type)}
                      </div>
                      <div>
                        <div className="flex items-center space-x-2 mb-1">
                          <h4 className="font-semibold text-slate-900">
                            {getClientName(alert.clientId)}
                          </h4>
                          <Badge className={getSeverityColor(alert.severity)}>
                            {alert.severity}
                          </Badge>
                          <Badge variant="outline" className="capitalize">
                            {alert.type.replace('_', ' ')}
                          </Badge>
                          {alert.acknowledged && (
                            <Badge variant="outline" className="bg-green-50 text-green-700">
                              Acknowledged
                            </Badge>
                          )}
                        </div>
                        <p className="text-slate-700">{alert.message}</p>
                        <div className="flex items-center space-x-4 mt-2">
                          <span className="text-xs text-slate-500">
                            {new Date(alert.timestamp).toLocaleString()}
                          </span>
                          {!alert.acknowledged && (
                            <span className="text-xs text-blue-600 font-medium">
                              Action: {alert.recommendedAction}
                            </span>
                          )}
                        </div>
                      </div>
                    </div>
                    <div className="flex items-center space-x-2">
                      {!alert.acknowledged && (
                        <Button 
                          variant="outline" 
                          size="sm"
                          onClick={() => acknowledgeAlert(alert.id)}
                        >
                          <CheckCircle className="h-4 w-4 mr-1" />
                          Acknowledge
                        </Button>
                      )}
                      <Button 
                        variant="ghost" 
                        size="sm"
                        onClick={() => dismissAlert(alert.id)}
                      >
                        <X className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Alert Types Guide */}
      <Card>
        <CardHeader>
          <CardTitle className="text-lg">Alert Types Guide</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            <div className="p-4 bg-pink-50 rounded-lg">
              <div className="flex items-center space-x-2 mb-2">
                <Heart className="h-5 w-5 text-pink-500" />
                <h4 className="font-semibold text-pink-900">Life Events</h4>
              </div>
              <p className="text-sm text-pink-700">
                Triggered when significant life events are detected that may impact risk tolerance 
                (marriage, job change, health issues, etc.)
              </p>
            </div>

            <div className="p-4 bg-purple-50 rounded-lg">
              <div className="flex items-center space-x-2 mb-2">
                <Brain className="h-5 w-5 text-purple-500" />
                <h4 className="font-semibold text-purple-900">Behavioral Changes</h4>
              </div>
              <p className="text-sm text-purple-700">
                Detected through monitoring of portfolio checking frequency, trading patterns, 
                and login behavior during volatility.
              </p>
            </div>

            <div className="p-4 bg-red-50 rounded-lg">
              <div className="flex items-center space-x-2 mb-2">
                <TrendingDown className="h-5 w-5 text-red-500" />
                <h4 className="font-semibold text-red-900">Market Impact</h4>
              </div>
              <p className="text-sm text-red-700">
                Alerts when market conditions may affect client goals or when significant 
                market movements are detected.
              </p>
            </div>

            <div className="p-4 bg-amber-50 rounded-lg">
              <div className="flex items-center space-x-2 mb-2">
                <AlertTriangle className="h-5 w-5 text-amber-500" />
                <h4 className="font-semibold text-amber-900">Misalignment</h4>
              </div>
              <p className="text-sm text-amber-700">
                Triggered when portfolio allocation deviates significantly from the 
                client's risk profile recommendations.
              </p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
