import { useState } from 'react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { AlertCircle, TrendingUp, Users, Activity, Brain, Zap } from 'lucide-react';
import type { RiskProfile } from '@/types';
import { sampleClients } from '@/data/sampleClients';
import ClientProfile from '@/sections/ClientProfile';
import LifeEventSimulator from '@/sections/LifeEventSimulator';
import BehavioralDashboard from '@/sections/BehavioralDashboard';
import RiskScoringEngine from '@/sections/RiskScoringEngine';
import AlertPanel from '@/sections/AlertPanel';

function App() {
  const [selectedClient, setSelectedClient] = useState<RiskProfile>(sampleClients[0]);
  const [activeTab, setActiveTab] = useState('overview');

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100">
      {/* Header */}
      <header className="bg-white border-b border-slate-200 sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center space-x-3">
              <div className="bg-gradient-to-r from-blue-600 to-indigo-600 p-2 rounded-lg">
                <Activity className="h-6 w-6 text-white" />
              </div>
              <div>
                <h1 className="text-xl font-bold bg-gradient-to-r from-blue-700 to-indigo-700 bg-clip-text text-transparent">
                  RiskPulse
                </h1>
                <p className="text-xs text-slate-500">Dynamic Risk Tolerance Monitor</p>
              </div>
            </div>
            <div className="flex items-center space-x-4">
              <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
                <Zap className="h-3 w-3 mr-1" />
                Live Monitoring
              </Badge>
              <div className="text-sm text-slate-600">
                {new Date().toLocaleDateString('en-US', { 
                  weekday: 'short', 
                  year: 'numeric', 
                  month: 'short', 
                  day: 'numeric' 
                })}
              </div>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Stats Overview */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
          <Card className="bg-gradient-to-br from-blue-50 to-blue-100 border-blue-200">
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-blue-600 font-medium">Total Clients</p>
                  <p className="text-2xl font-bold text-blue-900">{sampleClients.length}</p>
                </div>
                <Users className="h-8 w-8 text-blue-500" />
              </div>
            </CardContent>
          </Card>
          <Card className="bg-gradient-to-br from-green-50 to-green-100 border-green-200">
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-green-600 font-medium">Stable</p>
                  <p className="text-2xl font-bold text-green-900">3</p>
                </div>
                <TrendingUp className="h-8 w-8 text-green-500" />
              </div>
            </CardContent>
          </Card>
          <Card className="bg-gradient-to-br from-amber-50 to-amber-100 border-amber-200">
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-amber-600 font-medium">Monitoring</p>
                  <p className="text-2xl font-bold text-amber-900">1</p>
                </div>
                <Brain className="h-8 w-8 text-amber-500" />
              </div>
            </CardContent>
          </Card>
          <Card className="bg-gradient-to-br from-red-50 to-red-100 border-red-200">
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-red-600 font-medium">Alerts</p>
                  <p className="text-2xl font-bold text-red-900">4</p>
                </div>
                <AlertCircle className="h-8 w-8 text-red-500" />
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Main Tabs */}
        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
          <TabsList className="grid grid-cols-6 gap-4 bg-white p-1 rounded-xl border border-slate-200">
            <TabsTrigger value="overview" className="rounded-lg data-[state=active]:bg-blue-50 data-[state=active]:text-blue-700">
              Overview
            </TabsTrigger>
            <TabsTrigger value="clients" className="rounded-lg data-[state=active]:bg-blue-50 data-[state=active]:text-blue-700">
              Client Profiles
            </TabsTrigger>
            <TabsTrigger value="life-events" className="rounded-lg data-[state=active]:bg-blue-50 data-[state=active]:text-blue-700">
              Life Events
            </TabsTrigger>
            <TabsTrigger value="behavioral" className="rounded-lg data-[state=active]:bg-blue-50 data-[state=active]:text-blue-700">
              Behavioral
            </TabsTrigger>
            <TabsTrigger value="scoring" className="rounded-lg data-[state=active]:bg-blue-50 data-[state=active]:text-blue-700">
              Risk Scoring
            </TabsTrigger>
            <TabsTrigger value="alerts" className="rounded-lg data-[state=active]:bg-blue-50 data-[state=active]:text-blue-700">
              Alerts
            </TabsTrigger>
          </TabsList>

          <TabsContent value="overview" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Dynamic Risk Tolerance Monitoring Dashboard</CardTitle>
                <CardDescription>
                  Comprehensive simulation for monitoring changes in client risk tolerance
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-4">
                    <h3 className="text-lg font-semibold text-slate-900">Key Features</h3>
                    <ul className="space-y-2">
                      <li className="flex items-start space-x-2">
                        <div className="w-2 h-2 rounded-full bg-blue-500 mt-2" />
                        <span className="text-slate-700"><strong>Life Event Triggers:</strong> Monitor how major life events impact risk tolerance</span>
                      </li>
                      <li className="flex items-start space-x-2">
                        <div className="w-2 h-2 rounded-full bg-green-500 mt-2" />
                        <span className="text-slate-700"><strong>Behavioral Indicators:</strong> Track portfolio checking, trading patterns, and emotional states</span>
                      </li>
                      <li className="flex items-start space-x-2">
                        <div className="w-2 h-2 rounded-full bg-amber-500 mt-2" />
                        <span className="text-slate-700"><strong>Dynamic Scoring:</strong> Real-time risk score calculation with weighted components</span>
                      </li>
                      <li className="flex items-start space-x-2">
                        <div className="w-2 h-2 rounded-full bg-purple-500 mt-2" />
                        <span className="text-slate-700"><strong>Portfolio Alignment:</strong> Ensure portfolios match risk profiles</span>
                      </li>
                    </ul>
                  </div>
                  <div className="space-y-4">
                    <h3 className="text-lg font-semibold text-slate-900">Methodology</h3>
                    <div className="bg-slate-50 p-4 rounded-lg space-y-3">
                      <div className="flex justify-between items-center">
                        <span className="text-sm text-slate-600">Financial Capacity</span>
                        <Badge variant="secondary">25% weight</Badge>
                      </div>
                      <div className="flex justify-between items-center">
                        <span className="text-sm text-slate-600">Risk Attitude</span>
                        <Badge variant="secondary">25% weight</Badge>
                      </div>
                      <div className="flex justify-between items-center">
                        <span className="text-sm text-slate-600">Risk Knowledge</span>
                        <Badge variant="secondary">15% weight</Badge>
                      </div>
                      <div className="flex justify-between items-center">
                        <span className="text-sm text-slate-600">Behavioral Consistency</span>
                        <Badge variant="secondary">20% weight</Badge>
                      </div>
                      <div className="flex justify-between items-center">
                        <span className="text-sm text-slate-600">Life Event Impact</span>
                        <Badge variant="secondary">10% weight</Badge>
                      </div>
                      <div className="flex justify-between items-center">
                        <span className="text-sm text-slate-600">Market Conditions</span>
                        <Badge variant="secondary">5% weight</Badge>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Quick Client Summary */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {sampleClients.slice(0, 3).map(client => (
                <Card key={client.id} className="cursor-pointer hover:shadow-lg transition-shadow"
                  onClick={() => { setSelectedClient(client); setActiveTab('clients'); }}>
                  <CardContent className="p-4">
                    <div className="flex items-center justify-between mb-2">
                      <h4 className="font-semibold text-slate-900">{client.clientName}</h4>
                      <Badge className={
                        client.compositeScore >= 65 ? 'bg-green-100 text-green-800' :
                        client.compositeScore >= 50 ? 'bg-blue-100 text-blue-800' :
                        'bg-amber-100 text-amber-800'
                      }>
                        Score: {client.compositeScore}
                      </Badge>
                    </div>
                    <p className="text-sm text-slate-600">{client.occupation}, Age {client.age}</p>
                    <div className="mt-3 flex items-center space-x-2">
                      <div className="flex-1 bg-slate-200 rounded-full h-2">
                        <div 
                          className={`h-2 rounded-full ${
                            client.compositeScore >= 65 ? 'bg-green-500' :
                            client.compositeScore >= 50 ? 'bg-blue-500' :
                            'bg-amber-500'
                          }`}
                          style={{ width: `${client.compositeScore}%` }}
                        />
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="clients">
            <ClientProfile 
              client={selectedClient} 
              onClientChange={setSelectedClient}
              allClients={sampleClients}
            />
          </TabsContent>

          <TabsContent value="life-events">
            <LifeEventSimulator client={selectedClient} />
          </TabsContent>

          <TabsContent value="behavioral">
            <BehavioralDashboard client={selectedClient} />
          </TabsContent>

          <TabsContent value="scoring">
            <RiskScoringEngine client={selectedClient} />
          </TabsContent>

          <TabsContent value="alerts">
            <AlertPanel />
          </TabsContent>
        </Tabs>
      </main>

      {/* Footer */}
      <footer className="bg-white border-t border-slate-200 mt-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="flex items-center justify-between">
            <p className="text-sm text-slate-500">
              RiskPulse™ - Dynamic Risk Intelligence Simulator
            </p>
            <p className="text-sm text-slate-400">
              Based on behavioral finance research and industry best practices
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}

export default App;
