// Risk Tolerance Types
export interface RiskProfile {
  id: string;
  clientName: string;
  age: number;
  occupation: string;
  income: number;
  familyStatus: FamilyStatus;
  financialGoals: FinancialGoal[];
  riskCapacity: number; // 0-100
  riskAttitude: number; // 0-100
  riskKnowledge: number; // 0-100
  compositeScore: number; // 0-100
  lastAssessment: Date;
  assessmentHistory: AssessmentRecord[];
}

export type FamilyStatus = 
  | 'single' 
  | 'married_no_children' 
  | 'married_with_children' 
  | 'divorced' 
  | 'widowed' 
  | 'retired';

export interface FinancialGoal {
  id: string;
  name: string;
  targetAmount: number;
  targetDate: Date;
  priority: 'low' | 'medium' | 'high';
  goalType: GoalType;
}

export type GoalType = 
  | 'emergency_fund'
  | 'retirement'
  | 'education'
  | 'home_purchase'
  | 'wealth_accumulation'
  | 'legacy_planning';

export interface AssessmentRecord {
  date: Date;
  riskCapacity: number;
  riskAttitude: number;
  riskKnowledge: number;
  compositeScore: number;
  trigger?: LifeEventType;
}

// Life Event Types
export type LifeEventType = 
  | 'marriage'
  | 'divorce'
  | 'birth_of_child'
  | 'death_of_spouse'
  | 'job_change'
  | 'promotion'
  | 'job_loss'
  | 'health_diagnosis'
  | 'inheritance'
  | 'home_purchase'
  | 'retirement'
  | 'market_crash'
  | 'market_boom';

export interface LifeEvent {
  id: string;
  type: LifeEventType;
  name: string;
  description: string;
  impact: {
    riskCapacity: number; // -20 to +20
    riskAttitude: number; // -20 to +20
    duration: number; // months
  };
  probability: number; // 0-1
  ageRange: [number, number];
}

// Behavioral Indicators
export interface BehavioralIndicators {
  portfolioCheckingFrequency: number; // times per week
  tradingFrequency: number; // trades per month
  averageHoldingPeriod: number; // days
  contributionConsistency: number; // 0-100
  panicSellTendency: number; // 0-100
  fomoTendency: number; // 0-100
  rebalancingDiscipline: number; // 0-100
  lastLoginDays: number;
  loginDuringVolatility: boolean;
  portfolioReviewPattern: 'frequent' | 'moderate' | 'rare';
}

export interface BehavioralMetrics {
  date: Date;
  loginCount: number;
  portfolioViews: number;
  tradesExecuted: number;
  supportCalls: number;
  contentConsumed: string[];
  emotionalState?: EmotionalState;
}

export type EmotionalState = 
  | 'calm'
  | 'anxious'
  | 'excited'
  | 'fearful'
  | 'overconfident'
  | 'indifferent';

// Dynamic Risk Scoring
export interface RiskScoreComponents {
  financialCapacity: number; // 0-100
  riskAttitude: number; // 0-100
  riskKnowledge: number; // 0-100
  behavioralConsistency: number; // 0-100
  lifeEventImpact: number; // -20 to +20
  marketConditionImpact: number; // -10 to +10
}

export interface DynamicRiskScore {
  overallScore: number; // 0-100
  confidence: number; // 0-100
  components: RiskScoreComponents;
  trend: 'increasing' | 'decreasing' | 'stable';
  trendMagnitude: number;
  lastUpdated: Date;
  recommendedAction: RiskAction;
}

export type RiskAction = 
  | 'maintain'
  | 'review_recommended'
  | 'rebalance_required'
  | 'immediate_attention';

// Portfolio Types
export interface Portfolio {
  id: string;
  clientId: string;
  totalValue: number;
  allocations: AssetAllocation[];
  riskMetrics: PortfolioRiskMetrics;
  lastRebalanced: Date;
}

export interface AssetAllocation {
  assetClass: AssetClass;
  percentage: number;
  value: number;
}

export type AssetClass = 
  | 'large_cap_equity'
  | 'mid_cap_equity'
  | 'small_cap_equity'
  | 'international_equity'
  | 'government_bonds'
  | 'corporate_bonds'
  | 'short_term_debt'
  | 'real_estate'
  | 'gold'
  | 'cash';

export interface PortfolioRiskMetrics {
  standardDeviation: number;
  beta: number;
  var95: number; // Value at Risk at 95% confidence
  maxDrawdown: number;
  sharpeRatio: number;
  sortinoRatio: number;
}

// Simulation Types
export interface SimulationScenario {
  id: string;
  name: string;
  description: string;
  duration: number; // months
  events: ScheduledEvent[];
  marketConditions: MarketCondition[];
}

export interface ScheduledEvent {
  month: number;
  event: LifeEvent;
}

export interface MarketCondition {
  month: number;
  condition: 'bull' | 'bear' | 'volatile' | 'stable';
  indexReturn: number;
  volatility: number;
}

export interface SimulationResult {
  scenarioId: string;
  clientId: string;
  startDate: Date;
  endDate: Date;
  initialScore: number;
  finalScore: number;
  scoreHistory: ScoreHistoryPoint[];
  decisions: DecisionRecord[];
  portfolioValue: number;
  goalAchievement: number; // 0-100
}

export interface ScoreHistoryPoint {
  date: Date;
  score: number;
  trigger?: LifeEventType;
}

export interface DecisionRecord {
  date: Date;
  context: string;
  options: DecisionOption[];
  selectedOption: string;
  impact: number;
}

export interface DecisionOption {
  id: string;
  label: string;
  description: string;
  riskImpact: number;
}

// Dashboard Types
export interface Alert {
  id: string;
  clientId: string;
  type: 'life_event' | 'behavioral_change' | 'market_impact' | 'misalignment';
  severity: 'low' | 'medium' | 'high' | 'critical';
  message: string;
  timestamp: Date;
  acknowledged: boolean;
  recommendedAction: string;
}

export interface ClientSummary {
  id: string;
  name: string;
  age: number;
  currentScore: number;
  scoreChange: number;
  portfolioValue: number;
  alerts: number;
  lastActivity: Date;
  status: 'stable' | 'monitoring' | 'attention_required';
}
