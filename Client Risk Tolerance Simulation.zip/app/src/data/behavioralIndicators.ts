import type { BehavioralIndicators, BehavioralMetrics, EmotionalState } from '@/types';

export interface BehavioralIndicatorConfig {
  id: string;
  name: string;
  description: string;
  normalRange: [number, number];
  warningThreshold: number;
  criticalThreshold: number;
  riskImpact: 'low' | 'medium' | 'high';
  interpretation: {
    low: string;
    normal: string;
    high: string;
  };
}

export const behavioralIndicatorConfigs: BehavioralIndicatorConfig[] = [
  {
    id: 'bi_001',
    name: 'Portfolio Checking Frequency',
    description: 'Number of times client checks portfolio per week',
    normalRange: [1, 3],
    warningThreshold: 7,
    criticalThreshold: 14,
    riskImpact: 'medium',
    interpretation: {
      low: 'Low engagement, may miss important updates',
      normal: 'Healthy monitoring frequency',
      high: 'Excessive checking may indicate anxiety and lead to impulsive decisions'
    }
  },
  {
    id: 'bi_002',
    name: 'Trading Frequency',
    description: 'Number of trades executed per month',
    normalRange: [0, 2],
    warningThreshold: 5,
    criticalThreshold: 10,
    riskImpact: 'high',
    interpretation: {
      low: 'Disciplined long-term approach',
      normal: 'Appropriate rebalancing activity',
      high: 'Excessive trading may indicate overconfidence or panic reactions'
    }
  },
  {
    id: 'bi_003',
    name: 'Average Holding Period',
    description: 'Average days positions are held',
    normalRange: [365, 1825],
    warningThreshold: 180,
    criticalThreshold: 90,
    riskImpact: 'high',
    interpretation: {
      low: 'Short-term trading, high turnover',
      normal: 'Long-term investment horizon',
      high: 'Very long-term holding, appropriate for retirement goals'
    }
  },
  {
    id: 'bi_004',
    name: 'Contribution Consistency',
    description: 'Consistency of regular contributions (0-100)',
    normalRange: [80, 100],
    warningThreshold: 60,
    criticalThreshold: 40,
    riskImpact: 'medium',
    interpretation: {
      low: 'Frequent contribution changes may indicate financial stress',
      normal: 'Consistent investment discipline',
      high: 'Excellent savings discipline'
    }
  },
  {
    id: 'bi_005',
    name: 'Panic Sell Tendency',
    description: 'Likelihood of selling during market downturns (0-100)',
    normalRange: [0, 30],
    warningThreshold: 50,
    criticalThreshold: 70,
    riskImpact: 'high',
    interpretation: {
      low: 'Strong emotional composure during volatility',
      normal: 'Some concern during downturns but maintains discipline',
      high: 'High risk of making emotionally-driven poor decisions'
    }
  },
  {
    id: 'bi_006',
    name: 'FOMO Tendency',
    description: 'Fear of missing out on market rallies (0-100)',
    normalRange: [0, 30],
    warningThreshold: 50,
    criticalThreshold: 70,
    riskImpact: 'medium',
    interpretation: {
      low: 'Resistant to market hype',
      normal: 'Some susceptibility to market sentiment',
      high: 'High risk of chasing performance and buying at peaks'
    }
  },
  {
    id: 'bi_007',
    name: 'Rebalancing Discipline',
    description: 'Adherence to rebalancing schedule (0-100)',
    normalRange: [70, 100],
    warningThreshold: 50,
    criticalThreshold: 30,
    riskImpact: 'medium',
    interpretation: {
      low: 'Poor portfolio maintenance, may drift from target allocation',
      normal: 'Reasonable rebalancing discipline',
      high: 'Excellent portfolio management discipline'
    }
  }
];

export const calculateBehavioralRiskScore = (indicators: BehavioralIndicators): number => {
  // Calculate behavioral risk score (0-100, higher = more risky behavior)
  let score = 50; // Base score

  // Portfolio checking (excessive = anxiety)
  if (indicators.portfolioCheckingFrequency > 10) score += 15;
  else if (indicators.portfolioCheckingFrequency > 5) score += 8;
  else if (indicators.portfolioCheckingFrequency < 1) score -= 5;

  // Trading frequency (excessive = overtrading)
  if (indicators.tradingFrequency > 8) score += 20;
  else if (indicators.tradingFrequency > 4) score += 10;
  else if (indicators.tradingFrequency <= 2) score -= 10;

  // Holding period (short = speculation)
  if (indicators.averageHoldingPeriod < 90) score += 15;
  else if (indicators.averageHoldingPeriod < 180) score += 8;
  else if (indicators.averageHoldingPeriod > 365) score -= 10;

  // Contribution consistency (inconsistent = financial stress)
  score += (100 - indicators.contributionConsistency) * 0.2;

  // Panic sell tendency (high = emotional)
  score += indicators.panicSellTendency * 0.3;

  // FOMO tendency (high = chasing performance)
  score += indicators.fomoTendency * 0.2;

  // Rebalancing discipline (poor = drift)
  score += (100 - indicators.rebalancingDiscipline) * 0.15;

  // Login during volatility (indicates anxiety)
  if (indicators.loginDuringVolatility) score += 10;

  return Math.max(0, Math.min(100, score));
};

export const generateSampleBehavioralMetrics = (months: number = 12): BehavioralMetrics[] => {
  const metrics: BehavioralMetrics[] = [];
  const now = new Date();

  for (let i = 0; i < months; i++) {
    const date = new Date(now);
    date.setMonth(date.getMonth() - i);

    // Simulate market volatility impact on behavior
    const isVolatile = Math.random() > 0.7;
    const emotionalState: EmotionalState = isVolatile 
      ? (Math.random() > 0.5 ? 'anxious' : 'fearful')
      : 'calm';

    metrics.push({
      date,
      loginCount: isVolatile ? Math.floor(Math.random() * 20) + 10 : Math.floor(Math.random() * 8) + 2,
      portfolioViews: isVolatile ? Math.floor(Math.random() * 30) + 15 : Math.floor(Math.random() * 10) + 3,
      tradesExecuted: isVolatile ? Math.floor(Math.random() * 5) + 1 : Math.floor(Math.random() * 2),
      supportCalls: isVolatile ? Math.floor(Math.random() * 3) : 0,
      contentConsumed: isVolatile 
        ? ['market_news', 'risk_management', 'portfolio_protection']
        : ['general_updates'],
      emotionalState
    });
  }

  return metrics.reverse();
};

export const getEmotionalStateDescription = (state: EmotionalState): string => {
  const descriptions: Record<EmotionalState, string> = {
    calm: 'Rational and composed, makes balanced decisions',
    anxious: 'Worried about portfolio performance, may make hasty decisions',
    excited: 'Overly optimistic, may take excessive risks',
    fearful: 'Significantly worried about losses, may sell at wrong time',
    overconfident: 'Excessively self-assured, may underestimate risks',
    indifferent: 'Disengaged from portfolio, may miss important signals'
  };
  return descriptions[state];
};
