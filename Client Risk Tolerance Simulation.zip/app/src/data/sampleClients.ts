import type { RiskProfile, BehavioralIndicators, Alert } from '@/types';

export const sampleClients: RiskProfile[] = [
  {
    id: 'cli_001',
    clientName: 'Rahul Sharma',
    age: 32,
    occupation: 'Software Engineer',
    income: 1800000,
    familyStatus: 'married_no_children',
    financialGoals: [
      {
        id: 'goal_001',
        name: 'Emergency Fund',
        targetAmount: 500000,
        targetDate: new Date('2025-12-31'),
        priority: 'high',
        goalType: 'emergency_fund'
      },
      {
        id: 'goal_002',
        name: 'Home Down Payment',
        targetAmount: 3000000,
        targetDate: new Date('2027-06-30'),
        priority: 'high',
        goalType: 'home_purchase'
      }
    ],
    riskCapacity: 75,
    riskAttitude: 70,
    riskKnowledge: 65,
    compositeScore: 70,
    lastAssessment: new Date('2024-01-15'),
    assessmentHistory: [
      { date: new Date('2023-01-15'), riskCapacity: 70, riskAttitude: 75, riskKnowledge: 60, compositeScore: 68 },
      { date: new Date('2023-07-15'), riskCapacity: 72, riskAttitude: 72, riskKnowledge: 62, compositeScore: 69 },
      { date: new Date('2024-01-15'), riskCapacity: 75, riskAttitude: 70, riskKnowledge: 65, compositeScore: 70 }
    ]
  },
  {
    id: 'cli_002',
    clientName: 'Priya Patel',
    age: 45,
    occupation: 'Marketing Director',
    income: 2500000,
    familyStatus: 'married_with_children',
    financialGoals: [
      {
        id: 'goal_003',
        name: "Children's Education",
        targetAmount: 5000000,
        targetDate: new Date('2030-06-30'),
        priority: 'high',
        goalType: 'education'
      },
      {
        id: 'goal_004',
        name: 'Retirement Corpus',
        targetAmount: 10000000,
        targetDate: new Date('2045-03-31'),
        priority: 'high',
        goalType: 'retirement'
      }
    ],
    riskCapacity: 60,
    riskAttitude: 55,
    riskKnowledge: 75,
    compositeScore: 63,
    lastAssessment: new Date('2024-02-01'),
    assessmentHistory: [
      { date: new Date('2022-02-01'), riskCapacity: 65, riskAttitude: 60, riskKnowledge: 70, compositeScore: 65 },
      { date: new Date('2023-02-01'), riskCapacity: 62, riskAttitude: 58, riskKnowledge: 72, compositeScore: 64 },
      { date: new Date('2024-02-01'), riskCapacity: 60, riskAttitude: 55, riskKnowledge: 75, compositeScore: 63 }
    ]
  },
  {
    id: 'cli_003',
    clientName: 'Vikram Mehta',
    age: 58,
    occupation: 'Business Owner',
    income: 5000000,
    familyStatus: 'married_with_children',
    financialGoals: [
      {
        id: 'goal_005',
        name: 'Retirement Planning',
        targetAmount: 15000000,
        targetDate: new Date('2027-03-31'),
        priority: 'high',
        goalType: 'retirement'
      },
      {
        id: 'goal_006',
        name: 'Legacy Planning',
        targetAmount: 5000000,
        targetDate: new Date('2035-12-31'),
        priority: 'medium',
        goalType: 'legacy_planning'
      }
    ],
    riskCapacity: 45,
    riskAttitude: 40,
    riskKnowledge: 80,
    compositeScore: 55,
    lastAssessment: new Date('2024-01-20'),
    assessmentHistory: [
      { date: new Date('2020-01-20'), riskCapacity: 60, riskAttitude: 55, riskKnowledge: 75, compositeScore: 63 },
      { date: new Date('2022-01-20'), riskCapacity: 52, riskAttitude: 48, riskKnowledge: 78, compositeScore: 59 },
      { date: new Date('2024-01-20'), riskCapacity: 45, riskAttitude: 40, riskKnowledge: 80, compositeScore: 55 }
    ]
  },
  {
    id: 'cli_004',
    clientName: 'Ananya Gupta',
    age: 28,
    occupation: 'Data Scientist',
    income: 1200000,
    familyStatus: 'single',
    financialGoals: [
      {
        id: 'goal_007',
        name: 'Wealth Accumulation',
        targetAmount: 2000000,
        targetDate: new Date('2030-12-31'),
        priority: 'medium',
        goalType: 'wealth_accumulation'
      },
      {
        id: 'goal_008',
        name: 'Emergency Fund',
        targetAmount: 400000,
        targetDate: new Date('2025-06-30'),
        priority: 'high',
        goalType: 'emergency_fund'
      }
    ],
    riskCapacity: 85,
    riskAttitude: 80,
    riskKnowledge: 70,
    compositeScore: 78,
    lastAssessment: new Date('2024-03-01'),
    assessmentHistory: [
      { date: new Date('2023-03-01'), riskCapacity: 80, riskAttitude: 85, riskKnowledge: 65, compositeScore: 77 },
      { date: new Date('2024-03-01'), riskCapacity: 85, riskAttitude: 80, riskKnowledge: 70, compositeScore: 78 }
    ]
  },
  {
    id: 'cli_005',
    clientName: 'Suresh Kumar',
    age: 52,
    occupation: 'Senior Manager',
    income: 2200000,
    familyStatus: 'married_with_children',
    financialGoals: [
      {
        id: 'goal_009',
        name: 'Retirement Corpus',
        targetAmount: 8000000,
        targetDate: new Date('2032-03-31'),
        priority: 'high',
        goalType: 'retirement'
      }
    ],
    riskCapacity: 50,
    riskAttitude: 45,
    riskKnowledge: 70,
    compositeScore: 55,
    lastAssessment: new Date('2024-02-15'),
    assessmentHistory: [
      { date: new Date('2020-02-15'), riskCapacity: 65, riskAttitude: 60, riskKnowledge: 65, compositeScore: 63 },
      { date: new Date('2022-02-15'), riskCapacity: 58, riskAttitude: 52, riskKnowledge: 68, compositeScore: 59 },
      { date: new Date('2024-02-15'), riskCapacity: 50, riskAttitude: 45, riskKnowledge: 70, compositeScore: 55 }
    ]
  }
];

export const sampleBehavioralData: Record<string, BehavioralIndicators> = {
  'cli_001': {
    portfolioCheckingFrequency: 3,
    tradingFrequency: 2,
    averageHoldingPeriod: 450,
    contributionConsistency: 95,
    panicSellTendency: 20,
    fomoTendency: 25,
    rebalancingDiscipline: 85,
    lastLoginDays: 2,
    loginDuringVolatility: false,
    portfolioReviewPattern: 'moderate'
  },
  'cli_002': {
    portfolioCheckingFrequency: 2,
    tradingFrequency: 1,
    averageHoldingPeriod: 820,
    contributionConsistency: 90,
    panicSellTendency: 30,
    fomoTendency: 15,
    rebalancingDiscipline: 75,
    lastLoginDays: 5,
    loginDuringVolatility: false,
    portfolioReviewPattern: 'moderate'
  },
  'cli_003': {
    portfolioCheckingFrequency: 1,
    tradingFrequency: 0,
    averageHoldingPeriod: 1460,
    contributionConsistency: 85,
    panicSellTendency: 15,
    fomoTendency: 10,
    rebalancingDiscipline: 70,
    lastLoginDays: 7,
    loginDuringVolatility: false,
    portfolioReviewPattern: 'rare'
  },
  'cli_004': {
    portfolioCheckingFrequency: 8,
    tradingFrequency: 4,
    averageHoldingPeriod: 280,
    contributionConsistency: 80,
    panicSellTendency: 35,
    fomoTendency: 45,
    rebalancingDiscipline: 60,
    lastLoginDays: 1,
    loginDuringVolatility: true,
    portfolioReviewPattern: 'frequent'
  },
  'cli_005': {
    portfolioCheckingFrequency: 4,
    tradingFrequency: 2,
    averageHoldingPeriod: 650,
    contributionConsistency: 88,
    panicSellTendency: 40,
    fomoTendency: 20,
    rebalancingDiscipline: 65,
    lastLoginDays: 3,
    loginDuringVolatility: true,
    portfolioReviewPattern: 'moderate'
  }
};

export const sampleAlerts: Alert[] = [
  {
    id: 'alt_001',
    clientId: 'cli_004',
    type: 'behavioral_change',
    severity: 'medium',
    message: 'Client showing increased portfolio checking frequency and trading activity during volatile period',
    timestamp: new Date('2024-03-10'),
    acknowledged: false,
    recommendedAction: 'Schedule check-in call to discuss market volatility concerns'
  },
  {
    id: 'alt_002',
    clientId: 'cli_005',
    type: 'misalignment',
    severity: 'high',
    message: 'Portfolio risk level exceeds current risk tolerance score by 15%',
    timestamp: new Date('2024-03-08'),
    acknowledged: false,
    recommendedAction: 'Recommend portfolio rebalancing to align with risk profile'
  },
  {
    id: 'alt_003',
    clientId: 'cli_002',
    type: 'life_event',
    severity: 'medium',
    message: 'Client approaching key education funding milestone - review allocation',
    timestamp: new Date('2024-03-05'),
    acknowledged: true,
    recommendedAction: 'Schedule goal-based portfolio review'
  },
  {
    id: 'alt_004',
    clientId: 'cli_001',
    type: 'market_impact',
    severity: 'low',
    message: 'Market volatility may affect near-term home purchase goal',
    timestamp: new Date('2024-03-12'),
    acknowledged: false,
    recommendedAction: 'Monitor goal timeline and consider goal-based allocation'
  }
];

export const getClientById = (id: string): RiskProfile | undefined => {
  return sampleClients.find(client => client.id === id);
};

export const getClientBehavioralData = (clientId: string): BehavioralIndicators => {
  return sampleBehavioralData[clientId] || sampleBehavioralData['cli_001'];
};

export const getClientAlerts = (clientId: string): Alert[] => {
  return sampleAlerts.filter(alert => alert.clientId === clientId);
};
