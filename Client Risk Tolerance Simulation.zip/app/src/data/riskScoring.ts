import type { 
  RiskProfile, 
  DynamicRiskScore, 
  LifeEvent,
  BehavioralIndicators 
} from '@/types';

// Dynamic Risk Scoring Methodology
// Based on research: weighted scoring combining multiple factors

export interface ScoringWeights {
  financialCapacity: number;
  riskAttitude: number;
  riskKnowledge: number;
  behavioralConsistency: number;
  lifeEventImpact: number;
  marketConditionImpact: number;
}

// Default weights based on industry best practices
export const defaultWeights: ScoringWeights = {
  financialCapacity: 0.25,
  riskAttitude: 0.25,
  riskKnowledge: 0.15,
  behavioralConsistency: 0.20,
  lifeEventImpact: 0.10,
  marketConditionImpact: 0.05
};

// Market condition multipliers
export const marketConditionMultipliers = {
  bull: { capacity: 1.0, attitude: 1.1 },
  bear: { capacity: 0.95, attitude: 0.8 },
  volatile: { capacity: 0.9, attitude: 0.75 },
  stable: { capacity: 1.0, attitude: 1.0 }
};

export type MarketCondition = keyof typeof marketConditionMultipliers;

/**
 * Calculate Financial Capacity Score (0-100)
 * Based on: income stability, emergency reserves, debt levels, time horizon
 */
export const calculateFinancialCapacity = (
  income: number,
  emergencyMonths: number,
  debtToIncome: number,
  age: number,
  retirementAge: number = 60
): number => {
  let score = 50; // Base score

  // Income factor (higher income = higher capacity)
  if (income > 2000000) score += 15;
  else if (income > 1000000) score += 10;
  else if (income > 500000) score += 5;
  else if (income < 300000) score -= 10;

  // Emergency reserves (more months = higher capacity)
  if (emergencyMonths >= 12) score += 15;
  else if (emergencyMonths >= 6) score += 10;
  else if (emergencyMonths >= 3) score += 5;
  else score -= 10;

  // Debt-to-income ratio (lower = higher capacity)
  if (debtToIncome < 0.2) score += 10;
  else if (debtToIncome < 0.36) score += 5;
  else if (debtToIncome > 0.5) score -= 15;
  else if (debtToIncome > 0.4) score -= 10;

  // Time horizon (younger = higher capacity)
  const yearsToRetirement = retirementAge - age;
  if (yearsToRetirement > 25) score += 10;
  else if (yearsToRetirement > 15) score += 5;
  else if (yearsToRetirement < 5) score -= 15;
  else if (yearsToRetirement < 10) score -= 10;

  return Math.max(0, Math.min(100, score));
};

/**
 * Calculate Risk Attitude Score (0-100)
 * Based on psychometric assessment responses
 */
export const calculateRiskAttitude = (
  lossTolerance: number, // 0-100 (higher = more tolerant)
  volatilityComfort: number, // 0-100
  decisionStyle: 'analytical' | 'intuitive' | 'emotional',
  pastExperience: 'positive' | 'neutral' | 'negative'
): number => {
  let score = 50;

  // Loss tolerance
  score += (lossTolerance - 50) * 0.4;

  // Volatility comfort
  score += (volatilityComfort - 50) * 0.4;

  // Decision style adjustment
  const decisionMultipliers = {
    analytical: 5,
    intuitive: 0,
    emotional: -10
  };
  score += decisionMultipliers[decisionStyle];

  // Past experience adjustment
  const experienceMultipliers = {
    positive: 10,
    neutral: 0,
    negative: -15
  };
  score += experienceMultipliers[pastExperience];

  return Math.max(0, Math.min(100, score));
};

/**
 * Calculate Risk Knowledge Score (0-100)
 * Based on financial literacy and investment understanding
 */
export const calculateRiskKnowledge = (
  investmentExperience: number, // years
  financialLiteracyScore: number, // 0-100
  diversificationUnderstanding: boolean,
  marketMechanismKnowledge: boolean
): number => {
  let score = 40; // Base score

  // Investment experience
  if (investmentExperience > 15) score += 20;
  else if (investmentExperience > 10) score += 15;
  else if (investmentExperience > 5) score += 10;
  else if (investmentExperience > 2) score += 5;

  // Financial literacy
  score += financialLiteracyScore * 0.3;

  // Diversification understanding
  if (diversificationUnderstanding) score += 10;

  // Market mechanism knowledge
  if (marketMechanismKnowledge) score += 10;

  return Math.max(0, Math.min(100, score));
};

/**
 * Calculate Behavioral Consistency Score (0-100)
 * Compares stated preferences with revealed preferences
 */
export const calculateBehavioralConsistency = (
  statedRiskTolerance: number,
  behavioralIndicators: BehavioralIndicators,
  historicalDecisions: { expected: number; actual: number }[]
): number => {
  let score = 70; // Base score

  // Calculate behavioral risk score
  const behavioralRisk = 50 + 
    (behavioralIndicators.portfolioCheckingFrequency > 5 ? 10 : 0) +
    (behavioralIndicators.tradingFrequency > 4 ? 10 : 0) +
    (behavioralIndicators.panicSellTendency * 0.3) +
    (behavioralIndicators.fomoTendency * 0.2);

  // Compare stated vs behavioral
  const difference = Math.abs(statedRiskTolerance - (100 - behavioralRisk));
  
  if (difference < 10) score += 20;
  else if (difference < 20) score += 10;
  else if (difference < 30) score += 0;
  else score -= 15;

  // Historical decision consistency
  if (historicalDecisions.length > 0) {
    const avgDeviation = historicalDecisions.reduce(
      (sum, d) => sum + Math.abs(d.expected - d.actual), 
      0
    ) / historicalDecisions.length;
    
    if (avgDeviation < 5) score += 10;
    else if (avgDeviation > 20) score -= 15;
    else if (avgDeviation > 10) score -= 5;
  }

  // Portfolio checking pattern
  if (behavioralIndicators.portfolioCheckingFrequency > 10) score -= 10;
  else if (behavioralIndicators.portfolioCheckingFrequency > 5) score -= 5;

  // Trading frequency
  if (behavioralIndicators.tradingFrequency > 8) score -= 10;

  return Math.max(0, Math.min(100, score));
};

/**
 * Calculate Life Event Impact Score (-20 to +20)
 */
export const calculateLifeEventImpact = (
  recentEvents: LifeEvent[],
  monthsSinceEvent: number[]
): number => {
  if (recentEvents.length === 0) return 0;

  let totalImpact = 0;

  recentEvents.forEach((event, index) => {
    const monthsAgo = monthsSinceEvent[index] || 0;
    const decayFactor = Math.max(0, 1 - (monthsAgo / event.impact.duration));
    
    const eventImpact = (event.impact.riskCapacity + event.impact.riskAttitude) / 2;
    totalImpact += eventImpact * decayFactor;
  });

  return Math.max(-20, Math.min(20, totalImpact));
};

/**
 * Calculate Dynamic Risk Score
 * Main scoring function combining all components
 */
export const calculateDynamicRiskScore = (
  profile: RiskProfile,
  behavioralIndicators: BehavioralIndicators,
  recentLifeEvents: LifeEvent[] = [],
  eventMonthsAgo: number[] = [],
  marketCondition: MarketCondition = 'stable',
  weights: ScoringWeights = defaultWeights
): DynamicRiskScore => {
  // Calculate component scores
  const components = {
    financialCapacity: profile.riskCapacity,
    riskAttitude: profile.riskAttitude,
    riskKnowledge: profile.riskKnowledge,
    behavioralConsistency: calculateBehavioralConsistency(
      profile.compositeScore,
      behavioralIndicators,
      []
    ),
    lifeEventImpact: calculateLifeEventImpact(recentLifeEvents, eventMonthsAgo),
    marketConditionImpact: 0 // Will be applied as multiplier
  };

  // Apply market condition multipliers
  const multipliers = marketConditionMultipliers[marketCondition];
  const adjustedCapacity = components.financialCapacity * multipliers.capacity;
  const adjustedAttitude = components.riskAttitude * multipliers.attitude;

  // Calculate weighted overall score
  const overallScore = 
    (adjustedCapacity * weights.financialCapacity) +
    (adjustedAttitude * weights.riskAttitude) +
    (components.riskKnowledge * weights.riskKnowledge) +
    (components.behavioralConsistency * weights.behavioralConsistency) +
    (components.lifeEventImpact * weights.lifeEventImpact) +
    (components.marketConditionImpact * weights.marketConditionImpact);

  // Determine trend
  const history = profile.assessmentHistory;
  let trend: 'increasing' | 'decreasing' | 'stable' = 'stable';
  let trendMagnitude = 0;

  if (history.length >= 2) {
    const recent = history.slice(-3);
    const avgRecent = recent.reduce((sum, h) => sum + h.compositeScore, 0) / recent.length;
    const previous = history.slice(-6, -3);
    const avgPrevious = previous.length > 0 
      ? previous.reduce((sum, h) => sum + h.compositeScore, 0) / previous.length 
      : history[0].compositeScore;
    
    trendMagnitude = avgRecent - avgPrevious;
    
    if (trendMagnitude > 5) trend = 'increasing';
    else if (trendMagnitude < -5) trend = 'decreasing';
  }

  // Determine recommended action
  let recommendedAction: DynamicRiskScore['recommendedAction'] = 'maintain';
  
  if (overallScore < 30 || components.behavioralConsistency < 40) {
    recommendedAction = 'immediate_attention';
  } else if (overallScore < 50 || Math.abs(components.lifeEventImpact) > 10) {
    recommendedAction = 'rebalance_required';
  } else if (overallScore < 65 || trendMagnitude < -10) {
    recommendedAction = 'review_recommended';
  }

  // Calculate confidence based on data quality
  const confidence = Math.min(100, 
    50 + 
    (history.length * 5) + 
    (components.behavioralConsistency * 0.3)
  );

  return {
    overallScore: Math.max(0, Math.min(100, overallScore)),
    confidence,
    components,
    trend,
    trendMagnitude,
    lastUpdated: new Date(),
    recommendedAction
  };
};

/**
 * Get risk category label
 */
export const getRiskCategory = (score: number): string => {
  if (score >= 80) return 'Aggressive';
  if (score >= 65) return 'Growth';
  if (score >= 50) return 'Moderate';
  if (score >= 35) return 'Conservative';
  return 'Very Conservative';
};

/**
 * Get recommended asset allocation based on risk score
 */
export const getRecommendedAllocation = (score: number): Record<string, number> => {
  if (score >= 80) {
    // Aggressive
    return {
      large_cap_equity: 35,
      mid_cap_equity: 20,
      small_cap_equity: 15,
      international_equity: 15,
      corporate_bonds: 10,
      cash: 5
    };
  } else if (score >= 65) {
    // Growth
    return {
      large_cap_equity: 35,
      mid_cap_equity: 15,
      small_cap_equity: 10,
      international_equity: 15,
      government_bonds: 10,
      corporate_bonds: 10,
      cash: 5
    };
  } else if (score >= 50) {
    // Moderate
    return {
      large_cap_equity: 30,
      mid_cap_equity: 10,
      international_equity: 10,
      government_bonds: 25,
      corporate_bonds: 15,
      gold: 5,
      cash: 5
    };
  } else if (score >= 35) {
    // Conservative
    return {
      large_cap_equity: 20,
      government_bonds: 40,
      corporate_bonds: 20,
      gold: 10,
      cash: 10
    };
  } else {
    // Very Conservative
    return {
      large_cap_equity: 10,
      government_bonds: 50,
      corporate_bonds: 20,
      gold: 10,
      cash: 10
    };
  }
};
