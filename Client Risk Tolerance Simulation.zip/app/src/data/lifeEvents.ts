import type { LifeEvent, LifeEventType } from '@/types';

export const lifeEvents: LifeEvent[] = [
  {
    id: 'le_001',
    type: 'marriage',
    name: 'Marriage',
    description: 'Combining two financial profiles may introduce competing risk preferences and shared financial responsibilities.',
    impact: {
      riskCapacity: 5,
      riskAttitude: -5,
      duration: 12
    },
    probability: 0.028,
    ageRange: [25, 40]
  },
  {
    id: 'le_002',
    type: 'divorce',
    name: 'Divorce',
    description: 'Separation can significantly reduce risk capacity due to asset division and potential income changes.',
    impact: {
      riskCapacity: -15,
      riskAttitude: -10,
      duration: 24
    },
    probability: 0.015,
    ageRange: [30, 55]
  },
  {
    id: 'le_003',
    type: 'birth_of_child',
    name: 'Birth of Child',
    description: 'New parental responsibilities typically extend planning horizons while adding financial obligations.',
    impact: {
      riskCapacity: -5,
      riskAttitude: -10,
      duration: 36
    },
    probability: 0.032,
    ageRange: [25, 40]
  },
  {
    id: 'le_004',
    type: 'death_of_spouse',
    name: 'Death of Spouse',
    description: 'Loss of a spouse dramatically shifts both financial capacity and psychological outlook toward risk.',
    impact: {
      riskCapacity: -20,
      riskAttitude: -15,
      duration: 60
    },
    probability: 0.015,
    ageRange: [50, 80]
  },
  {
    id: 'le_005',
    type: 'job_change',
    name: 'Job Change',
    description: 'Career transition may affect income stability and risk capacity depending on new role security.',
    impact: {
      riskCapacity: -5,
      riskAttitude: 0,
      duration: 6
    },
    probability: 0.08,
    ageRange: [25, 55]
  },
  {
    id: 'le_006',
    type: 'promotion',
    name: 'Career Promotion',
    description: 'Increased income and job security can enhance risk capacity and confidence.',
    impact: {
      riskCapacity: 10,
      riskAttitude: 5,
      duration: 12
    },
    probability: 0.05,
    ageRange: [30, 50]
  },
  {
    id: 'le_007',
    type: 'job_loss',
    name: 'Job Loss',
    description: 'Unemployment significantly reduces risk capacity and often triggers conservative behavior.',
    impact: {
      riskCapacity: -20,
      riskAttitude: -15,
      duration: 12
    },
    probability: 0.045,
    ageRange: [25, 60]
  },
  {
    id: 'le_008',
    type: 'health_diagnosis',
    name: 'Serious Health Diagnosis',
    description: 'Health crisis affects both financial capacity (medical costs) and psychological risk attitude.',
    impact: {
      riskCapacity: -15,
      riskAttitude: -20,
      duration: 48
    },
    probability: 0.018,
    ageRange: [40, 75]
  },
  {
    id: 'le_009',
    type: 'inheritance',
    name: 'Inheritance Received',
    description: 'Sudden wealth can increase risk capacity but may also trigger more conservative preservation mindset.',
    impact: {
      riskCapacity: 15,
      riskAttitude: -5,
      duration: 18
    },
    probability: 0.02,
    ageRange: [40, 70]
  },
  {
    id: 'le_010',
    type: 'home_purchase',
    name: 'Home Purchase',
    description: 'Major asset acquisition reduces liquid assets and may constrain risk capacity.',
    impact: {
      riskCapacity: -10,
      riskAttitude: -5,
      duration: 24
    },
    probability: 0.038,
    ageRange: [28, 45]
  },
  {
    id: 'le_011',
    type: 'retirement',
    name: 'Retirement',
    description: 'Transition from accumulation to distribution phase fundamentally changes risk capacity and attitude.',
    impact: {
      riskCapacity: -15,
      riskAttitude: -10,
      duration: 120
    },
    probability: 0.03,
    ageRange: [58, 68]
  },
  {
    id: 'le_012',
    type: 'market_crash',
    name: 'Market Crash',
    description: 'Severe market decline often triggers myopic loss aversion and risk tolerance compression.',
    impact: {
      riskCapacity: 0,
      riskAttitude: -25,
      duration: 6
    },
    probability: 0.05,
    ageRange: [18, 80]
  },
  {
    id: 'le_013',
    type: 'market_boom',
    name: 'Market Boom',
    description: 'Extended bull market can create wealth effect and inflate risk tolerance inappropriately.',
    impact: {
      riskCapacity: 0,
      riskAttitude: 15,
      duration: 6
    },
    probability: 0.08,
    ageRange: [18, 80]
  }
];

export const getLifeEventByType = (type: LifeEventType): LifeEvent | undefined => {
  return lifeEvents.find(event => event.type === type);
};

export const getLifeEventsByAge = (age: number): LifeEvent[] => {
  return lifeEvents.filter(event => 
    age >= event.ageRange[0] && age <= event.ageRange[1]
  );
};

export const getHighImpactEvents = (): LifeEvent[] => {
  return lifeEvents.filter(event => 
    Math.abs(event.impact.riskCapacity) >= 15 || 
    Math.abs(event.impact.riskAttitude) >= 15
  );
};
